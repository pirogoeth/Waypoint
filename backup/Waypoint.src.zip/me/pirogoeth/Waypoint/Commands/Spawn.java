/*    */ package me.pirogoeth.Waypoint.Commands;
/*    */ 
/*    */ import me.pirogoeth.Waypoint.Util.Command;
/*    */ import me.pirogoeth.Waypoint.Util.CommandException;
/*    */ import me.pirogoeth.Waypoint.Util.Config;
/*    */ import me.pirogoeth.Waypoint.Util.Permission;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ class Spawn extends Command
/*    */ {
/*    */   public Configuration main;
/*    */   public Configuration spawn;
/*    */ 
/*    */   public Spawn(Waypoint instance)
/*    */   {
/* 20 */     super(instance);
/* 21 */     this.main = Config.getMain();
/* 22 */     this.spawn = Config.getSpawn();
/*    */     try {
/* 24 */       setCommand("spawn");
/* 25 */       addAlias("wpspawn");
/* 26 */       register();
/*    */     } catch (CommandException e) {
/* 28 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean run(Player player, String[] args)
/*    */     throws CommandException
/*    */   {
/* 35 */     if (!registered) {
/* 36 */       throw new CommandException("Command is not registered.");
/*    */     }
/* 38 */     if (!Permission.has(player, "waypoint.spawn")) {
/* 39 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 40 */       return true;
/*    */     }
/* 42 */     String subc = "";
/*    */     try {
/* 44 */       subc = args[0];
/*    */     }
/*    */     catch (ArrayIndexOutOfBoundsException e) {
/* 47 */       World w = player.getWorld();
/* 48 */       this.plugin.spawnManager.SendPlayerToSpawn(w, player);
/* 49 */       return true;
/*    */     }
/* 51 */     World w = this.plugin.getServer().getWorld(subc);
/* 52 */     if (w == null)
/*    */     {
/* 54 */       player.sendMessage("[Waypoint] World '" + subc + "' does not exist.");
/* 55 */       return true;
/*    */     }
/* 57 */     this.plugin.spawnManager.SendPlayerToSpawn(w, player);
/* 58 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.Spawn
 * JD-Core Version:    0.6.0
 */