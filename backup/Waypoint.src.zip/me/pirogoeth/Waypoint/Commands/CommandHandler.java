/*    */ package me.pirogoeth.Waypoint.Commands;
/*    */ 
/*    */ import me.pirogoeth.Waypoint.Util.Command;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ 
/*    */ public class CommandHandler
/*    */ {
/*    */   public Waypoint plugin;
/*    */   private Command home;
/*    */   private Command setSpawn;
/*    */   private Command setWarp;
/*    */   private Command spawnAdmin;
/*    */   private Command spawnCommand;
/*    */   private Command teleLocation;
/*    */   private Command teleport;
/*    */   private Command teleportHere;
/*    */   private Command warp;
/*    */   private Command waypoints;
/*    */   private Command warpAdmin;
/*    */   private Command worldCommand;
/*    */ 
/*    */   public CommandHandler(Waypoint instance)
/*    */   {
/* 41 */     this.plugin = instance;
/*    */ 
/* 43 */     this.home = new Home(this.plugin);
/* 44 */     this.setSpawn = new SetSpawn(this.plugin);
/* 45 */     this.setWarp = new SetWarp(this.plugin);
/* 46 */     this.spawnAdmin = new SpawnAdmin(this.plugin);
/* 47 */     this.spawnCommand = new SpawnCommand(this.plugin);
/* 48 */     this.teleLocation = new TeleLocation(this.plugin);
/* 49 */     this.teleport = new Teleport(this.plugin);
/* 50 */     this.teleportHere = new TeleportHere(this.plugin);
/* 51 */     this.warp = new Warp(this.plugin);
/* 52 */     this.waypoints = new Waypoints(this.plugin);
/* 53 */     this.warpAdmin = new WarpAdmin(this.plugin);
/* 54 */     this.worldCommand = new WorldCommand(this.plugin);
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.CommandHandler
 * JD-Core Version:    0.6.0
 */