/*    */ package me.pirogoeth.Waypoint.Commands;
/*    */ 
/*    */ import me.pirogoeth.Waypoint.Core.Spawn;
/*    */ import me.pirogoeth.Waypoint.Util.Command;
/*    */ import me.pirogoeth.Waypoint.Util.CommandException;
/*    */ import me.pirogoeth.Waypoint.Util.Config;
/*    */ import me.pirogoeth.Waypoint.Util.Permission;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ class SetSpawn extends Command
/*    */ {
/*    */   public Configuration main;
/*    */   public Configuration spawn;
/*    */ 
/*    */   public SetSpawn(Waypoint instance)
/*    */   {
/* 72 */     super(instance);
/* 73 */     this.main = Config.getMain();
/* 74 */     this.spawn = Config.getSpawn();
/*    */     try {
/* 76 */       setCommand("setspawn");
/* 77 */       addAlias("wpsetspawn");
/* 78 */       register();
/*    */     } catch (CommandException e) {
/* 80 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean run(Player player, String[] args)
/*    */     throws CommandException
/*    */   {
/* 87 */     if (!this.registered) {
/* 88 */       throw new CommandException("Command is not registered.");
/*    */     }
/* 90 */     if (!Permission.has(player, "waypoint.admin.spawn.set")) {
/* 91 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 92 */       return true;
/*    */     }
/* 94 */     String subc = "";
/* 95 */     World w = player.getWorld();
/* 96 */     this.plugin.spawnManager.SendPlayerToSpawn(w, player);
/* 97 */     player.sendMessage(ChatColor.AQUA + "[Waypoint] Spawn for world " + player.getWorld().getName() + " has been set.");
/* 98 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.SetSpawn
 * JD-Core Version:    0.6.0
 */