/*    */ package me.pirogoeth.Waypoint.Commands;
/*    */ 
/*    */ import me.pirogoeth.Waypoint.Core.Spawn;
/*    */ import me.pirogoeth.Waypoint.Util.Command;
/*    */ import me.pirogoeth.Waypoint.Util.CommandException;
/*    */ import me.pirogoeth.Waypoint.Util.Config;
/*    */ import me.pirogoeth.Waypoint.Util.Permission;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ class SpawnCommand extends Command
/*    */ {
/*    */   public Configuration main;
/*    */   public Configuration spawn;
/*    */ 
/*    */   public SpawnCommand(Waypoint instance)
/*    */   {
/* 21 */     super(instance);
/* 22 */     this.main = Config.getMain();
/* 23 */     this.spawn = Config.getSpawn();
/*    */     try {
/* 25 */       setCommand("spawn");
/* 26 */       addAlias("wpspawn");
/* 27 */       register();
/*    */     } catch (CommandException e) {
/* 29 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean run(Player player, String[] args)
/*    */     throws CommandException
/*    */   {
/* 36 */     if (!this.registered) {
/* 37 */       throw new CommandException("Command is not registered.");
/*    */     }
/* 39 */     if (!Permission.has(player, "waypoint.spawn")) {
/* 40 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 41 */       return true;
/*    */     }
/* 43 */     String subc = "";
/*    */     try {
/* 45 */       subc = args[0];
/*    */     }
/*    */     catch (ArrayIndexOutOfBoundsException e) {
/* 48 */       World w = player.getWorld();
/* 49 */       this.plugin.spawnManager.SendPlayerToSpawn(w, player);
/* 50 */       return true;
/*    */     }
/* 52 */     World w = this.plugin.getServer().getWorld(subc);
/* 53 */     if (w == null)
/*    */     {
/* 55 */       player.sendMessage("[Waypoint] World '" + subc + "' does not exist.");
/* 56 */       return true;
/*    */     }
/* 58 */     if (!Permission.has(player, String.format("waypoint.world.access.%s", new Object[] { w.getName().toString() }))) {
/* 59 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to enter this world.");
/* 60 */       return true;
/*    */     }
/* 62 */     this.plugin.spawnManager.SendPlayerToSpawn(w, player);
/* 63 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.SpawnCommand
 * JD-Core Version:    0.6.0
 */