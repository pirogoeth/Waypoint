/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.MinorUtils;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ import org.bukkit.util.config.ConfigurationNode;
/*     */ 
/*     */ class Waypoints extends Command
/*     */ {
/*     */   public Configuration main;
/*     */   public Configuration users;
/*     */ 
/*     */   public Waypoints(Waypoint instance)
/*     */   {
/*  23 */     super(instance);
/*  24 */     this.main = Config.getMain();
/*  25 */     this.users = Config.getUsers();
/*     */     try {
/*  27 */       setCommand("wp");
/*  28 */       addAlias("waypoint");
/*  29 */       register();
/*     */     } catch (CommandException e) {
/*  31 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/*  38 */     if (!this.registered) {
/*  39 */       throw new CommandException("Command is not registered.");
/*     */     }
/*  41 */     String subc = "";
/*     */     try {
/*  43 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  46 */       player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*  47 */       return true;
/*     */     }
/*  49 */     subc = subc.toLowerCase().toString();
/*  50 */     String arg = null;
/*     */     try {
/*  52 */       arg = args[1];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  55 */       arg = null;
/*     */     }
/*  57 */     if (subc.equalsIgnoreCase("add"))
/*     */     {
/*  59 */       if (arg == null) player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*  60 */       if (!Permission.has(player, "waypoint.basic.add")) {
/*  61 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  62 */         return true;
/*     */       }
/*  64 */       if (this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "world")) != null)
/*     */       {
/*  66 */         player.sendMessage("[Waypoint] Point '" + arg + "' already exists!");
/*  67 */         return true;
/*     */       }
/*     */ 
/*  70 */       this.users.setProperty(MinorUtils.UserNodeChomp(player, arg, "coord.X"), Double.valueOf(player.getLocation().getX()));
/*  71 */       this.users.setProperty(MinorUtils.UserNodeChomp(player, arg, "coord.Y"), Double.valueOf(player.getLocation().getY()));
/*  72 */       this.users.setProperty(MinorUtils.UserNodeChomp(player, arg, "coord.Z"), Double.valueOf(player.getLocation().getZ()));
/*     */ 
/*  76 */       this.users.setProperty(MinorUtils.UserNodeChomp(player, arg, "world"), player.getLocation().getWorld().getName().toString());
/*  77 */       this.users.save();
/*  78 */       player.sendMessage(ChatColor.GREEN + "[Waypoint] Set point '" + arg + "' in world '" + player.getLocation().getWorld().getName().toString() + "'.");
/*  79 */       return true;
/*     */     }
/*  81 */     if ((subc.equalsIgnoreCase("del")) || (subc.equalsIgnoreCase("delete")) || (subc.equalsIgnoreCase("remove")))
/*     */     {
/*  83 */       if (arg == null) player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*  84 */       if (!Permission.has(player, "waypoint.basic.delete")) {
/*  85 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  86 */         return true;
/*     */       }
/*  88 */       if (this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "world")) == null)
/*     */       {
/*  90 */         player.sendMessage(ChatColor.RED + "[Waypoint] Point '" + arg + "' does not exist!");
/*  91 */         return true;
/*     */       }
/*  93 */       this.users.removeProperty("users." + player.getName().toString() + "." + arg);
/*  94 */       player.sendMessage("[Waypoint] Point '" + arg + "' has been deleted.");
/*  95 */       this.users.save();
/*  96 */       return true;
/*     */     }
/*  98 */     if ((subc.equalsIgnoreCase("tp")) || (subc.equalsIgnoreCase("teleport")))
/*     */     {
/* 100 */       if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|help> [name]");
/* 101 */       if (!Permission.has(player, "waypoint.basic.teleport")) {
/* 102 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 103 */         return true;
/*     */       }
/* 105 */       if (this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "world")) == null)
/*     */       {
/* 107 */         player.sendMessage(ChatColor.RED + "[Waypoint] Point '" + arg + "' does not exist!");
/* 108 */         return true;
/*     */       }
/* 110 */       World w = this.plugin.getServer().getWorld(this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "world")).toString());
/* 111 */       double x = ((Double)this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "coord.X"))).doubleValue();
/* 112 */       double y = ((Double)this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "coord.Y"))).doubleValue();
/* 113 */       double z = ((Double)this.users.getProperty(MinorUtils.UserNodeChomp(player, arg, "coord.Z"))).doubleValue();
/*     */ 
/* 117 */       Location l = new Location(w, x, y, z);
/* 118 */       boolean su = player.teleport(l);
/* 119 */       if (su == true)
/*     */       {
/* 121 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] Successfully teleported to '" + arg + "'.");
/* 122 */         return true;
/*     */       }
/* 124 */       if (!su)
/*     */       {
/* 126 */         player.sendMessage(ChatColor.RED + "[Waypoint] Error while teleporting to '" + arg + "'.");
/* 127 */         return true;
/*     */       }
/* 129 */       return true;
/*     */     }
/* 131 */     if (subc.equalsIgnoreCase("invite"))
/*     */     {
/* 133 */       if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|invite|help> [name]");
/* 134 */       if (!Permission.has(player, "waypoint.basic.invite")) {
/* 135 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 136 */         return true;
/*     */       }String point;
/*     */       try {
/* 140 */         point = args[2];
/*     */       }
/*     */       catch (ArrayIndexOutOfBoundsException e) {
/* 143 */         player.sendMessage(ChatColor.RED + "Usage: /wp invite <playername> <point>");
/* 144 */         return true;
/*     */       }
/* 146 */       Player p = this.plugin.getServer().getPlayer(arg);
/* 147 */       if (p == null)
/*     */       {
/* 149 */         player.sendMessage(ChatColor.RED + "[Waypoint] Player " + arg + " is offline. Please resend the invitation when he/she is online.");
/* 150 */         return true;
/*     */       }
/* 152 */       if (!MinorUtils.CheckPointExists(this.users, player, point))
/*     */       {
/* 154 */         player.sendMessage(ChatColor.RED + "You do not own a point named '" + point + "'.");
/* 155 */         return true;
/*     */       }
/* 157 */       ConfigurationNode node = this.users.getNode(MinorUtils.BaseNodeChomp(player, point));
/* 158 */       MinorUtils.TransferNode(this.users, MinorUtils.InviteNodeChomp(p, point), node);
/* 159 */       p.sendMessage(ChatColor.AQUA + "[Waypoint] Player " + player.getName().toString() + " has invited you to use their waypoint '" + point + "'.");
/* 160 */       p.sendMessage(ChatColor.GREEN + "Type /wp accept " + point + " to accept their invite.");
/* 161 */       p.sendMessage(ChatColor.GREEN + "Or type /wp decline " + point + " to decline the invite.");
/* 162 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] Sent invite to " + p.getName().toString() + ".");
/* 163 */       this.users.save();
/* 164 */       return true;
/*     */     }
/* 166 */     if (subc.equalsIgnoreCase("accept"))
/*     */     {
/* 168 */       if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|invite|help> [name]");
/* 169 */       if (!Permission.has(player, "waypoint.basic.invite.accept")) {
/* 170 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 171 */         return true;
/*     */       }
/* 173 */       if (this.users.getProperty(MinorUtils.InviteNodeChomp(player, arg)) == null)
/*     */       {
/* 175 */         player.sendMessage(ChatColor.RED + "[Waypoint] You have no point invite by that name.");
/* 176 */         return true;
/*     */       }
/* 178 */       ConfigurationNode n = this.users.getNode(MinorUtils.InviteNodeChomp(player, arg));
/* 179 */       this.users.removeProperty(MinorUtils.InviteNodeChomp(player, arg));
/* 180 */       MinorUtils.TransferNode(this.users, MinorUtils.BaseNodeChomp(player, arg), n);
/* 181 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] The point '" + arg + "' is now available in your collection.");
/* 182 */       this.users.save();
/*     */     }
/* 184 */     else if (subc.equalsIgnoreCase("decline"))
/*     */     {
/* 186 */       if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|invite|help> [name]");
/* 187 */       if (!Permission.has(player, "waypoint.basic.invite.decline")) {
/* 188 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 189 */         return true;
/*     */       }
/* 191 */       if (this.users.getProperty(MinorUtils.InviteNodeChomp(player, arg)) == null)
/*     */       {
/* 193 */         player.sendMessage(ChatColor.RED + "[Waypoint] You have no point invite by that name.");
/* 194 */         return true;
/*     */       }
/* 196 */       this.users.removeProperty(MinorUtils.InviteNodeChomp(player, arg));
/* 197 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] The point invitation '" + arg + "' has been declined.");
/* 198 */       this.users.save();
/*     */     } else {
/* 200 */       if (subc.equalsIgnoreCase("list"))
/*     */       {
/* 202 */         if (!Permission.has(player, "waypoint.basic.list")) {
/* 203 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 204 */           return true;
/*     */         }
/* 206 */         if (this.users.getProperty("users." + player.getName().toString()) == null)
/*     */         {
/* 208 */           player.sendMessage(ChatColor.RED + "[Waypoint] You do not have any points to list.");
/* 209 */           return true;
/*     */         }
/* 211 */         player.sendMessage(ChatColor.YELLOW + "====[Waypoint] Point list:====");
/* 212 */         Map a = this.users.getNodes("users." + player.getName());
/* 213 */         if (a.size() == 0)
/*     */         {
/* 215 */           player.sendMessage(ChatColor.AQUA + " - No points have been created.");
/* 216 */           return true;
/*     */         }
/* 218 */         for (Map.Entry entry : a.entrySet())
/*     */         {
/* 220 */           player.sendMessage(ChatColor.GREEN + " - " + (String)entry.getKey());
/*     */         }
/* 222 */         return true;
/*     */       }
/* 224 */       if (subc.equalsIgnoreCase("test"))
/*     */       {
/* 226 */         if (!Permission.has(player, "waypoint.debug.config_node_test")) {
/* 227 */           return true;
/*     */         }
/*     */ 
/* 230 */         double x = player.getLocation().getX();
/* 231 */         double y = player.getLocation().getY();
/* 232 */         double z = player.getLocation().getZ();
/* 233 */         this.users.setProperty(MinorUtils.UserNodeChomp(player, "testnode", "coord.X"), Double.valueOf(x));
/* 234 */         this.users.setProperty(MinorUtils.UserNodeChomp(player, "testnode", "coord.Y"), Double.valueOf(y));
/* 235 */         this.users.setProperty(MinorUtils.UserNodeChomp(player, "testnode", "coord.Z"), Double.valueOf(z));
/* 236 */         this.users.save();
/* 237 */         ConfigurationNode n = this.users.getNode(MinorUtils.UserNodeChomp(player, "testnode", "coord"));
/* 238 */         MinorUtils.TransferNode(this.users, MinorUtils.UserNodeChomp(player, "testnode", "coord"), n);
/* 239 */         this.users.save();
/* 240 */         this.users.removeProperty(MinorUtils.BaseNodeChomp(player, "testnode"));
/* 241 */         this.users.save();
/* 242 */         this.log.info("Configuration node nesting test successful.");
/* 243 */         return true;
/*     */       }
/* 245 */       if (subc.equalsIgnoreCase("help"))
/*     */       {
/* 247 */         player.sendMessage(ChatColor.BLUE + "Waypoint, version " + this.plugin.getDescription().getVersion());
/* 248 */         player.sendMessage(ChatColor.GREEN + "/wp:");
/* 249 */         player.sendMessage(ChatColor.RED + "   add - add a waypoint to your list.");
/* 250 */         player.sendMessage(ChatColor.RED + "   del - remove a waypoint from your list.");
/* 251 */         player.sendMessage(ChatColor.RED + "   tp - teleport to a waypoint in your list.");
/* 252 */         player.sendMessage(ChatColor.RED + "   list - list the waypoints in your list.");
/* 253 */         player.sendMessage(ChatColor.RED + "   help - this message.");
/* 254 */         return true;
/*     */       }
/*     */ 
/* 258 */       player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/* 259 */       return true;
/*     */     }
/* 261 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.Waypoints
 * JD-Core Version:    0.6.0
 */