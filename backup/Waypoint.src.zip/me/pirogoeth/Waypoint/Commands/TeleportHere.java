/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Vehicle;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ class TeleportHere extends Command
/*     */ {
/*     */   public Configuration main;
/*     */ 
/*     */   public TeleportHere(Waypoint instance)
/*     */   {
/* 175 */     super(instance);
/* 176 */     this.main = Config.getMain();
/*     */     try {
/* 178 */       setCommand("tphere");
/* 179 */       addAlias("teleporthere");
/* 180 */       addAlias("wptphere");
/* 181 */       register();
/*     */     } catch (CommandException e) {
/* 183 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/* 190 */     if (!this.registered) {
/* 191 */       throw new CommandException("Command is not registered.");
/*     */     }
/* 193 */     if (!Permission.has(player, "waypoint.teleport.here")) {
/* 194 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 195 */       return true;
/*     */     }
/* 197 */     String subc = "";
/*     */     try {
/* 199 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 202 */       player.sendMessage("Usage: /tphere <target>");
/* 203 */       return true;
/*     */     }
/* 205 */     subc = subc.toLowerCase().toString();
/* 206 */     Player target = this.plugin.getServer().getPlayer(subc);
/* 207 */     if (target == null)
/*     */     {
/* 209 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] Player " + subc + " is not online.");
/* 210 */       return true;
/*     */     }
/* 212 */     Location l = player.getLocation();
/* 213 */     if (!Permission.has(target, String.format("waypoint.world.access.%s", new Object[] { l.getWorld().getName().toString() }))) {
/* 214 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] " + target.getName().toString() + " does not have permission to enter this world.");
/* 215 */       return true;
/*     */     }
/* 217 */     Vehicle target_veh = target.getVehicle();
/* 218 */     if (target_veh != null) target_veh.eject();
/* 219 */     target.teleport(l);
/* 220 */     target.sendMessage(ChatColor.GREEN + "[Waypoint] You have been teleported to " + player.getName().toString() + ".");
/* 221 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.TeleportHere
 * JD-Core Version:    0.6.0
 */