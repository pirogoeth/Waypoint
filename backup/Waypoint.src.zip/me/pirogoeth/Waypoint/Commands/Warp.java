/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import me.pirogoeth.Waypoint.Core.Warps;
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ import org.bukkit.util.config.ConfigurationNode;
/*     */ 
/*     */ class Warp extends Command
/*     */ {
/*     */   public Configuration main;
/*     */   public Configuration warp;
/*     */ 
/*     */   public Warp(Waypoint instance)
/*     */   {
/*  23 */     super(instance);
/*  24 */     this.main = Config.getMain();
/*  25 */     this.warp = Config.getWarp();
/*     */     try {
/*  27 */       setCommand("warp");
/*  28 */       addAlias("wpwarp");
/*  29 */       register();
/*     */     } catch (CommandException e) {
/*  31 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/*  38 */     if (!this.registered) {
/*  39 */       throw new CommandException("Command is not registered.");
/*     */     }
/*  41 */     if (!Permission.has(player, "waypoint.warp")) {
/*  42 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  43 */       return true;
/*     */     }
/*  45 */     String subc = "";
/*  46 */     String arg = "";
/*  47 */     String k = "";
/*  48 */     String v = "";
/*     */     try {
/*  50 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  53 */       player.sendMessage("Usage: /warp <add|del|set|list|<warp name>> [key] [value]");
/*  54 */       return true;
/*     */     }
/*  56 */     String origc = subc;
/*     */     try
/*     */     {
/*  60 */       arg = args[1];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  63 */       arg = null;
/*     */     }
/*     */     try {
/*  66 */       k = args[2];
/*  67 */       v = args[3];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  70 */       k = null;
/*  71 */       v = null;
/*     */     }
/*  73 */     if (subc.equalsIgnoreCase("add"))
/*     */     {
/*  75 */       if (arg == null)
/*     */       {
/*  77 */         player.sendMessage(ChatColor.RED + "/warp add <warpname>");
/*  78 */         return true;
/*     */       }
/*  80 */       if (!Permission.has(player, "waypoint.warp.create"))
/*     */       {
/*  82 */         player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/*  83 */         return true;
/*     */       }
/*  85 */       this.plugin.warpManager.CreateWarp(player, arg);
/*  86 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] Warp " + arg + " has been created.");
/*  87 */       return true;
/*     */     }
/*  89 */     if (subc.equalsIgnoreCase("del"))
/*     */     {
/*  91 */       if (arg == null)
/*     */       {
/*  93 */         player.sendMessage(ChatColor.RED + "/warp del <warpname>");
/*  94 */         return true;
/*     */       }
/*  96 */       if (this.warp.getProperty(this.plugin.warpManager.WarpBase(arg)) == null)
/*     */       {
/*  98 */         player.sendMessage(ChatColor.RED + "[Waypoint] There is no warp by that name.");
/*  99 */         return true;
/*     */       }
/* 101 */       String owner = (String)this.warp.getProperty(this.plugin.warpManager.WarpNode(arg, "owner"));
/* 102 */       if ((!Permission.has(player, "waypoint.warp.delete")) || (!owner.equals(player.getName().toString())))
/*     */       {
/* 104 */         player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/* 105 */         return true;
/*     */       }
/* 107 */       this.plugin.warpManager.DeleteWarp(arg);
/* 108 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] Warp " + arg + " has been deleted.");
/* 109 */       return true;
/*     */     }
/* 111 */     if (subc.equalsIgnoreCase("remote"))
/*     */     {
/* 113 */       if ((arg == null) || (k == null))
/*     */       {
/* 115 */         player.sendMessage(ChatColor.RED + "/warp remote <player> <warpname>");
/* 116 */         return true;
/*     */       }
/* 118 */       if (!Permission.has(player, "waypoint.warp.remote"))
/*     */       {
/* 120 */         player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/* 121 */         return true;
/*     */       }
/* 123 */       Player target = this.plugin.getServer().getPlayer(arg);
/* 124 */       if (target == null)
/*     */       {
/* 126 */         player.sendMessage(ChatColor.RED + "[Waypoint] Player " + arg + " is not online.");
/* 127 */         return true;
/*     */       }
/* 129 */       boolean remote = this.plugin.warpManager.RemoteWarp(target, player, k);
/* 130 */       return true;
/*     */     }
/* 132 */     if (subc.equalsIgnoreCase("set"))
/*     */     {
/* 134 */       if (arg == null)
/*     */       {
/* 136 */         player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 137 */         return true;
/*     */       }
/* 139 */       if (k == null)
/*     */       {
/* 141 */         player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 142 */         return true;
/*     */       }
/* 144 */       if (v == null)
/*     */       {
/* 146 */         player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 147 */         return true;
/*     */       }
/*     */ 
/* 159 */       String owner = (String)this.warp.getProperty(this.plugin.warpManager.WarpNode(arg, "owner"));
/* 160 */       if (!owner.equals(player.getName().toString()))
/*     */       {
/* 162 */         player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission modify this warp.");
/* 163 */         return true;
/*     */       }
/*     */ 
/* 170 */       if (this.warp.getProperty(this.plugin.warpManager.WarpNode(arg, "permission")) == null)
/*     */       {
/* 172 */         player.sendMessage(ChatColor.RED + "[Waypoint] This warp does not exist.");
/* 173 */         return true;
/*     */       }
/* 175 */       boolean f = this.plugin.warpManager.SetWarpProp(arg, k, v);
/* 176 */       if (!f)
/*     */       {
/* 178 */         player.sendMessage(ChatColor.RED + "[Waypoint] An error occurred while trying to set the properties of warp: " + arg);
/* 179 */         return true;
/*     */       }
/* 181 */       if (f)
/*     */       {
/* 183 */         player.sendMessage(ChatColor.GREEN + "[Waypoint] Successfully set the property '" + k + "' to '" + v + "' for warp " + arg);
/* 184 */         return true;
/*     */       }
/* 186 */       return true;
/*     */     }
/* 188 */     if (subc.equalsIgnoreCase("list"))
/*     */     {
/* 190 */       if (!Permission.has(player, "waypoint.warp.list"))
/*     */       {
/* 192 */         player.sendMessage(ChatColor.RED + "[Waypoint] You do not have the permission to access this command.");
/* 193 */         return true;
/*     */       }
/* 195 */       int x = 0;
/*     */ 
/* 197 */       Map a = this.warp.getNodes("warps");
/* 198 */       if ((a == null) || (a.size() == 0))
/*     */       {
/* 200 */         player.sendMessage(ChatColor.YELLOW + "[Waypoint] There are currently no warps to be displayed.");
/* 201 */         return true;
/*     */       }
/* 203 */       player.sendMessage(ChatColor.GREEN + "====[Waypoint] Warps available to you:====");
/* 204 */       for (Map.Entry entry : a.entrySet())
/*     */       {
/* 206 */         ConfigurationNode node = (ConfigurationNode)entry.getValue();
/* 207 */         String warppermission = (String)node.getProperty("permission");
/* 208 */         if (warppermission == null)
/*     */         {
/* 210 */           player.sendMessage(ChatColor.RED + "[Waypoint] You have not set any warp permission groups to your configuration.");
/* 211 */           return true;
/*     */         }
/* 213 */         if (this.plugin.warpManager.checkperms(player, warppermission))
/*     */         {
/* 215 */           if ((!player.getWorld().toString().equals((String)node.getProperty("world"))) && (((String)Config.getMain().getProperty("warp.list_world_only")).equals("true")))
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 221 */           player.sendMessage(ChatColor.AQUA + " - " + (String)entry.getKey());
/*     */         }
/*     */ 
/* 224 */         x++;
/*     */       }
/* 226 */       if (x == 0)
/*     */       {
/* 228 */         player.sendMessage(ChatColor.YELLOW + "[Waypoint] There are currently no warps to be displayed.");
/*     */       }
/* 230 */       return true;
/*     */     }
/*     */ 
/* 233 */     if (this.warp.getProperty(this.plugin.warpManager.WarpBase(origc)) != null)
/*     */     {
/* 235 */       this.plugin.warpManager.PlayerToWarp(player, origc);
/* 236 */       return true;
/*     */     }
/* 238 */     if (this.warp.getProperty(this.plugin.warpManager.WarpBase(origc)) == null)
/*     */     {
/* 240 */       player.sendMessage(ChatColor.LIGHT_PURPLE + "[Waypoint] Warp " + origc + " does not exist.");
/* 241 */       return true;
/*     */     }
/* 243 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.Warp
 * JD-Core Version:    0.6.0
 */