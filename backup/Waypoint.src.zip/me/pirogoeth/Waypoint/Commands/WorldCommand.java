/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.pirogoeth.Waypoint.Core.Worlds;
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ class WorldCommand extends Command
/*     */ {
/*     */   public Configuration main;
/*     */ 
/*     */   public WorldCommand(Waypoint instance)
/*     */   {
/*  25 */     super(instance);
/*  26 */     this.main = Config.getMain();
/*     */     try {
/*  28 */       setCommand("world");
/*  29 */       addAlias("wpworld");
/*  30 */       register();
/*     */     } catch (CommandException e) {
/*  32 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/*  39 */     if (!this.registered) {
/*  40 */       throw new CommandException("Command is not registered.");
/*     */     }
/*  42 */     if (!Permission.has(player, "waypoint.world")) {
/*  43 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  44 */       return true;
/*     */     }
/*  46 */     String subc = "";
/*  47 */     String arg = "";
/*     */     try {
/*  49 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  52 */       subc = null;
/*     */     }
/*  54 */     if (subc == null)
/*     */     {
/*  56 */       String worldname = player.getLocation().getWorld().getName().toString();
/*  57 */       player.sendMessage(ChatColor.BLUE + "You are currently in world: " + worldname);
/*  58 */       String x = Double.toString(player.getLocation().getX());
/*  59 */       String y = Double.toString(player.getLocation().getY());
/*  60 */       String z = Double.toString(player.getLocation().getZ());
/*  61 */       player.sendMessage(ChatColor.BLUE + "Your current position is: " + x + "," + y + "," + z);
/*  62 */       return true;
/*     */     }
/*  64 */     if (subc.equalsIgnoreCase("list"))
/*     */     {
/*  67 */       List w = this.plugin.getServer().getWorlds();
/*  68 */       player.sendMessage(ChatColor.GREEN + "World List: ");
/*  69 */       Iterator i = w.iterator();
/*     */ 
/*  71 */       while (i.hasNext())
/*     */       {
/*  73 */         World wx = (World)i.next();
/*  74 */         player.sendMessage(ChatColor.GREEN + " - " + wx.getName());
/*     */       }
/*  76 */       return true;
/*     */     }
/*  78 */     if (subc.equalsIgnoreCase("import"))
/*     */     {
/*  80 */       if (!Permission.has(player, "waypoint.admin.world.import")) {
/*  81 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  82 */         return true;
/*  85 */       }
/*     */ String worldname = args[1];
/*     */       String environ;
/*     */       try { environ = args[2]; } catch (ArrayIndexOutOfBoundsException e) {
/*  89 */         environ = null;
/*  90 */       }if (environ == null)
/*     */       {
/*  92 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] Please specify an environment type.");
/*  93 */         return true; } int mode;
/*     */       try { mode = Integer.valueOf(Integer.parseInt(args[3])).intValue(); } catch (ArrayIndexOutOfBoundsException e) {
/*  96 */         mode = 404;
/*  97 */       }World wx = this.plugin.worldManager.Import(worldname, environ.toUpperCase(), mode);
/*  98 */       if (wx == null)
/*     */       {
/* 100 */         player.sendMessage(ChatColor.RED + "World import failed.");
/* 101 */         return true;
/*     */       }
/* 103 */       Config.getWorld().setProperty("world." + worldname + ".env", environ.toUpperCase());
/* 104 */       Config.save();
/* 105 */       player.sendMessage(String.format("%s[Waypoint] Loaded world: { %s [ENV:%s] }", new Object[] { ChatColor.GREEN, worldname, environ.toUpperCase() }));
/* 106 */       return true;
/*     */     }
/* 108 */     if (subc.equalsIgnoreCase("create"))
/*     */     {
/* 110 */       if (!Permission.has(player, "waypoint.admin.world.create")) {
/* 111 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 112 */         return true;
/* 115 */       }
/*     */ String worldname = args[1];
/*     */       String environ;
/*     */       try { environ = args[2]; } catch (ArrayIndexOutOfBoundsException e) {
/* 119 */         environ = null;
/* 120 */       }World wx = null;
/* 121 */       if (environ == null)
/*     */       {
/* 123 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] Please specify an environment type.");
/* 124 */         return true; } int mode;
/*     */       try { mode = Integer.valueOf(Integer.parseInt(args[3])).intValue(); } catch (ArrayIndexOutOfBoundsException e) {
/* 127 */         mode = 404;
/* 128 */       }wx = this.plugin.worldManager.Create(worldname, environ.toUpperCase(), mode);
/* 129 */       if (wx == null)
/*     */       {
/* 131 */         player.sendMessage(String.format("%s[Waypoint] Could not create world: %s", new Object[] { ChatColor.RED, worldname }));
/* 132 */         return true;
/*     */       }
/* 134 */       Config.getWorld().setProperty("world." + worldname + ".env", environ.toUpperCase());
/* 135 */       Config.save();
/* 136 */       player.sendMessage(String.format("%s[Waypoint] Successfully created world: { %s [ENV: %s] }", new Object[] { ChatColor.GREEN, worldname, environ.toUpperCase() }));
/* 137 */       return true;
/*     */     }
/* 139 */     if (subc != null)
/*     */     {
/* 141 */       World w = this.plugin.getServer().getWorld(subc);
/* 142 */       if (w == null)
/*     */       {
/* 144 */         player.sendMessage(ChatColor.RED + "[Waypoint] World " + subc + " does not exist.");
/* 145 */         return true;
/*     */       }
/* 147 */       if (!Permission.has(player, "waypoint.world.teleport"))
/*     */       {
/* 149 */         player.sendMessage("[Waypoint] You do not have permission to use this command.");
/* 150 */         return true;
/*     */       }
/* 152 */       Location wsl = w.getSpawnLocation();
/* 153 */       if (player.getLocation().getWorld().getName().toString().equals(wsl.getWorld().getName().toString())) {
/* 154 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] You are already in " + wsl.getWorld().getName().toString());
/* 155 */         return true;
/*     */       }
/* 157 */       if (!Permission.has(player, String.format("waypoint.world.access.%s", new Object[] { wsl.getWorld().getName().toString() }))) {
/* 158 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to enter this world.");
/* 159 */         return true;
/*     */       }
/* 161 */       player.teleport(wsl);
/* 162 */       int mode = Integer.valueOf(Config.getWorld().getInt(String.format("worlds.%s.mode", new Object[] { subc }), 1)).intValue();
/*     */ 
/* 164 */       player.setGameMode(GameMode.getByValue(mode));
/* 165 */       player.sendMessage(ChatColor.GREEN + "[Waypoint] You have been taken to the spawn of world '" + w.getName().toString() + "'.");
/* 166 */       return true;
/*     */     }
/* 168 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.WorldCommand
 * JD-Core Version:    0.6.0
 */