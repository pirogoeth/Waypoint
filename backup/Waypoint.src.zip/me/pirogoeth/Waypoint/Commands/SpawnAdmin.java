/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import me.pirogoeth.Waypoint.Core.Spawn;
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ class SpawnAdmin extends Command
/*     */ {
/*     */   public Configuration main;
/*     */   public Configuration spawn;
/*     */ 
/*     */   public SpawnAdmin(Waypoint instance)
/*     */   {
/* 107 */     super(instance);
/* 108 */     this.main = Config.getMain();
/* 109 */     this.spawn = Config.getSpawn();
/*     */     try {
/* 111 */       setCommand("spawnadmin");
/* 112 */       addAlias("wpspawnadmin");
/* 113 */       register();
/*     */     } catch (CommandException e) {
/* 115 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/* 122 */     if (!this.registered) {
/* 123 */       throw new CommandException("Command is not registered.");
/*     */     }
/* 125 */     if (!Permission.has(player, "waypoint.admin.spawn")) {
/* 126 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 127 */       return true;
/*     */     }
/* 129 */     String subc = "";
/*     */     try {
/* 131 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 134 */       player.sendMessage("Usage: /spawnadmin <save|load;set> <world>");
/* 135 */       return true;
/*     */     }
/* 137 */     subc = subc.toLowerCase().toString();
/* 138 */     String arg = null;
/*     */     try {
/* 140 */       arg = args[1];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 143 */       arg = null;
/*     */     }
/* 145 */     if (subc.equalsIgnoreCase("save"))
/*     */     {
/* 147 */       if (!Permission.has(player, "waypoint.admin.spawn.save")) {
/* 148 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 149 */         return true;
/*     */       }
/* 151 */       if (arg == null)
/*     */       {
/* 153 */         World w = this.plugin.getServer().getWorld(player.getWorld().getName().toString());
/* 154 */         this.plugin.spawnManager.SaveWorldSpawnLocation(w);
/* 155 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly saved spawn point for world: " + w.getName().toString());
/* 156 */         return true;
/*     */       }
/* 158 */       World w = this.plugin.getServer().getWorld(arg);
/* 159 */       if (w == null) {
/* 160 */         player.sendMessage(ChatColor.RED + "[Waypoint] Invalid world: " + arg); return true;
/* 161 */       }this.plugin.spawnManager.SaveWorldSpawnLocation(w);
/* 162 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly saved spawn point for world: " + w.getName().toString());
/* 163 */       return true;
/*     */     }
/* 165 */     if (subc.equalsIgnoreCase("load"))
/*     */     {
/* 167 */       if (!Permission.has(player, "waypoint.admin.spawn.load")) {
/* 168 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 169 */         return true;
/*     */       }
/* 171 */       if (arg == null)
/*     */       {
/* 173 */         this.plugin.spawnManager.LoadWorldSpawnLocation(player.getWorld());
/* 174 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly reloaded spawn point for world: " + player.getWorld().getName().toString());
/* 175 */         return true;
/*     */       }
/* 177 */       this.plugin.spawnManager.LoadWorldSpawnLocation(player.getWorld());
/* 178 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly reloaded spawn point for world: " + player.getWorld().getName().toString());
/* 179 */       return true;
/*     */     }
/* 181 */     if (subc.equalsIgnoreCase("set"))
/*     */     {
/* 183 */       if (!Permission.has(player, "waypoint.admin.spawn.set")) {
/* 184 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 185 */         return true;
/*     */       }
/* 187 */       this.plugin.spawnManager.SetSpawnFromPlayer(player.getWorld(), player);
/* 188 */       player.getWorld().save();
/* 189 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] Set spawn point for world: " + player.getWorld().getName());
/* 190 */       return true;
/*     */     }
/* 192 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.SpawnAdmin
 * JD-Core Version:    0.6.0
 */