/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import me.pirogoeth.Waypoint.Core.Warps;
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ import org.bukkit.util.config.ConfigurationNode;
/*     */ 
/*     */ class WarpAdmin extends Command
/*     */ {
/*     */   public Configuration main;
/*     */   public Configuration warp;
/*     */ 
/*     */   public WarpAdmin(Waypoint instance)
/*     */   {
/* 291 */     super(instance);
/* 292 */     this.main = Config.getMain();
/* 293 */     this.warp = Config.getWarp();
/*     */     try {
/* 295 */       setCommand("warpadmin");
/* 296 */       addAlias("wpwarpadmin");
/* 297 */       register();
/*     */     } catch (CommandException e) {
/* 299 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/* 306 */     if (!this.registered) {
/* 307 */       throw new CommandException("Command is not registered.");
/*     */     }
/* 309 */     if (!Permission.has(player, "waypoint.admin.warp"))
/*     */     {
/* 311 */       player.sendMessage(ChatColor.BLUE + "You do not have the permission to use this command.");
/* 312 */       return true;
/*     */     }
/* 314 */     String subc = "";
/* 315 */     String arg = "";
/* 316 */     String k = "";
/* 317 */     String v = "";
/*     */     try {
/* 319 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 322 */       player.sendMessage("Usage: /warpadmin <del|set> [key] [value]");
/* 323 */       return true;
/*     */     }
/*     */     try {
/* 326 */       arg = args[1];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 329 */       arg = null;
/*     */     }
/*     */     try {
/* 332 */       k = args[2];
/* 333 */       v = args[3];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 336 */       k = null;
/* 337 */       v = null;
/*     */     }
/* 339 */     if (subc.equalsIgnoreCase("del"))
/*     */     {
/* 341 */       if (arg == null)
/*     */       {
/* 343 */         player.sendMessage(ChatColor.RED + "/warpadmin del <warpname>");
/* 344 */         return true;
/*     */       }
/* 346 */       if (this.warp.getProperty(this.plugin.warpManager.WarpBase(arg)) == null)
/*     */       {
/* 348 */         player.sendMessage(ChatColor.RED + "[Waypoint] There is no warp by that name.");
/* 349 */         return true;
/*     */       }
/* 351 */       if (!Permission.has(player, "waypoint.admin.warp.delete"))
/*     */       {
/* 353 */         player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/* 354 */         return true;
/*     */       }
/* 356 */       this.plugin.warpManager.DeleteWarp(arg);
/* 357 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] Warp " + arg + " has been deleted.");
/* 358 */       return true;
/*     */     }
/* 360 */     if (subc.equalsIgnoreCase("read"))
/*     */     {
/* 362 */       if (arg == null)
/*     */       {
/* 364 */         player.sendMessage(ChatColor.RED + "/warp read <warpname>");
/* 365 */         return true;
/*     */       }
/* 367 */       ConfigurationNode a = this.warp.getNode(this.plugin.warpManager.WarpBase(arg));
/* 368 */       if (a == null)
/*     */       {
/* 370 */         player.sendMessage("[Waypoint] No warp by that name.");
/* 371 */         return true;
/*     */       }
/* 373 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] Metadata for warp '" + arg + "':");
/* 374 */       Map b = a.getAll();
/* 375 */       for (Map.Entry entry : b.entrySet())
/*     */       {
/* 377 */         player.sendMessage(String.format("%s  %s -> %s%s", new Object[] { ChatColor.GREEN, (String)entry.getKey(), ChatColor.BLUE, entry.getValue().toString() }));
/*     */       }
/* 379 */       return true;
/*     */     }
/* 381 */     if (subc.equalsIgnoreCase("set"))
/*     */     {
/* 383 */       if (arg == null)
/*     */       {
/* 385 */         player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 386 */         return true;
/*     */       }
/* 388 */       if (k == null)
/*     */       {
/* 390 */         player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 391 */         return true;
/*     */       }
/* 393 */       if (v == null)
/*     */       {
/* 395 */         player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 396 */         return true;
/*     */       }
/* 398 */       String owner = (String)this.warp.getProperty(this.plugin.warpManager.WarpNode(arg, "owner"));
/* 399 */       if (this.warp.getProperty(this.plugin.warpManager.WarpNode(arg, "permission")) == null)
/*     */       {
/* 401 */         player.sendMessage(ChatColor.RED + "[Waypoint] This warp does not exist.");
/* 402 */         return true;
/*     */       }
/* 404 */       boolean f = this.plugin.warpManager.SetWarpProp(arg, k, v);
/* 405 */       if (!f)
/*     */       {
/* 407 */         player.sendMessage(ChatColor.RED + "[Waypoint] An error occurred while trying to set the properties of warp: " + arg);
/* 408 */         return true;
/*     */       }
/* 410 */       if (f)
/*     */       {
/* 412 */         player.sendMessage(ChatColor.GREEN + "[Waypoint] Successfully set the property '" + k + "' to '" + v + "' for warp " + arg);
/* 413 */         return true;
/*     */       }
/* 415 */       return true;
/*     */     }
/* 417 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.WarpAdmin
 * JD-Core Version:    0.6.0
 */