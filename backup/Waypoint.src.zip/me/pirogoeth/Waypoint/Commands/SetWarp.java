/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import me.pirogoeth.Waypoint.Core.Warps;
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ class SetWarp extends Command
/*     */ {
/*     */   public Configuration main;
/*     */ 
/*     */   public SetWarp(Waypoint instance)
/*     */   {
/* 251 */     super(instance);
/* 252 */     this.main = Config.getMain();
/*     */     try {
/* 254 */       setCommand("setwarp");
/* 255 */       addAlias("wpsetwarp");
/* 256 */       register();
/*     */     } catch (CommandException e) {
/* 258 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/* 265 */     if (!this.registered) {
/* 266 */       throw new CommandException("Command is not registered.");
/*     */     }
/* 268 */     if (!Permission.has(player, "waypoint.warp.create")) {
/* 269 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 270 */       return true;
/*     */     }
/* 272 */     String subc = "";
/*     */     try {
/* 274 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 277 */       player.sendMessage("Usage: /setwarp <name>");
/* 278 */       return true;
/*     */     }
/* 280 */     this.plugin.warpManager.CreateWarp(player, subc);
/* 281 */     player.sendMessage(ChatColor.AQUA + "[Waypoint] Warp " + subc + " has been created.");
/* 282 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.SetWarp
 * JD-Core Version:    0.6.0
 */