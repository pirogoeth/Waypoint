/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ class TeleLocation extends Command
/*     */ {
/*     */   public Configuration main;
/*     */ 
/*     */   public TeleLocation(Waypoint instance)
/*     */   {
/* 104 */     super(instance);
/* 105 */     this.main = Config.getMain();
/*     */     try {
/* 107 */       setCommand("tploc");
/* 108 */       addAlias("teleportlocation");
/* 109 */       addAlias("wptploc");
/* 110 */       register();
/*     */     } catch (CommandException e) {
/* 112 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/* 119 */     if (!this.registered) {
/* 120 */       throw new CommandException("Command is not registered.");
/*     */     }
/* 122 */     if (!Permission.has(player, "waypoint.teleport.location")) {
/* 123 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 124 */       return true;
/*     */     }
/* 126 */     String subc = "";
/* 127 */     String arg = null;
/*     */     try {
/* 129 */       if (args.length == 1) {
/* 130 */         arg = args[0];
/* 131 */       } else if (args.length == 3) {
/* 132 */         arg = String.format("%s,%s,%s", new Object[] { args[0], args[1], args[2] });
/*     */       } else {
/* 134 */         player.sendMessage(ChatColor.BLUE + "/tploc <x,y,z|x y z>");
/* 135 */         return true;
/*     */       }
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/* 139 */       arg = null;
/*     */     }
/* 141 */     if (arg != null) { World w;
/*     */       double x;
/*     */       double y;
/*     */       double z;
/*     */       try { String[] d = arg.split("\\,");
/* 149 */         w = player.getLocation().getWorld();
/* 150 */         x = new Double(d[0]).doubleValue();
/* 151 */         y = new Double(d[1]).doubleValue();
/* 152 */         z = new Double(d[2]).doubleValue();
/*     */       } catch (ArrayIndexOutOfBoundsException e)
/*     */       {
/* 155 */         player.sendMessage(ChatColor.RED + "[Waypoint] Invalid Coordinates.");
/* 156 */         return true;
/*     */       }
/* 158 */       Location l = new Location(w, Double.valueOf(x).doubleValue(), Double.valueOf(y).doubleValue(), Double.valueOf(z).doubleValue());
/* 159 */       player.teleport(l);
/* 160 */       return true;
/*     */     }
/* 162 */     if (arg == null)
/*     */     {
/* 164 */       player.sendMessage(ChatColor.RED + "[Waypoint] You need to provide a set of coordinates.");
/* 165 */       return true;
/*     */     }
/* 167 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.TeleLocation
 * JD-Core Version:    0.6.0
 */