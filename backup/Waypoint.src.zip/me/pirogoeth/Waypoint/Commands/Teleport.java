/*    */ package me.pirogoeth.Waypoint.Commands;
/*    */ 
/*    */ import me.pirogoeth.Waypoint.Util.Command;
/*    */ import me.pirogoeth.Waypoint.Util.CommandException;
/*    */ import me.pirogoeth.Waypoint.Util.Config;
/*    */ import me.pirogoeth.Waypoint.Util.Permission;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ class Teleport extends Command
/*    */ {
/*    */   public Configuration main;
/*    */ 
/*    */   public Teleport(Waypoint instance)
/*    */   {
/* 21 */     super(instance);
/* 22 */     this.main = Config.getMain();
/*    */     try {
/* 24 */       setCommand("tp");
/* 25 */       addAlias("teleport");
/* 26 */       addAlias("wptp");
/* 27 */       register();
/*    */     } catch (CommandException e) {
/* 29 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean run(Player player, String[] args)
/*    */     throws CommandException
/*    */   {
/* 36 */     if (!this.registered) {
/* 37 */       throw new CommandException("Command is not registered.");
/*    */     }
/* 39 */     if (!Permission.has(player, "waypoint.teleport.teleport")) {
/* 40 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/* 41 */       return true;
/*    */     }
/* 43 */     String subc = "";
/*    */     try {
/* 45 */       subc = args[0];
/*    */     }
/*    */     catch (ArrayIndexOutOfBoundsException e) {
/* 48 */       player.sendMessage("Usage: /tp <target> [user]");
/* 49 */       return true;
/*    */     }
/*    */ 
/* 54 */     String arg = null;
/*    */     try {
/* 56 */       arg = args[1];
/*    */     }
/*    */     catch (ArrayIndexOutOfBoundsException e) {
/* 59 */       arg = null;
/*    */     }
/* 61 */     if (arg == null)
/*    */     {
/* 63 */       Player target = this.plugin.getServer().getPlayer(subc);
/* 64 */       if (target == null)
/*    */       {
/* 66 */         player.sendMessage("[Waypoint] Player " + subc + " is not logged in.");
/* 67 */         return true;
/*    */       }
/* 69 */       Location l = target.getLocation();
/* 70 */       if (!Permission.has(player, String.format("waypoint.world.access.%s", new Object[] { l.getWorld().getName().toString() }))) {
/* 71 */         player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to enter this world.");
/* 72 */         return true;
/*    */       }
/* 74 */       player.teleport(l);
/* 75 */       return true;
/*    */     }
/* 77 */     if (arg != null)
/*    */     {
/* 79 */       Player p = this.plugin.getServer().getPlayer(subc);
/* 80 */       Player target = this.plugin.getServer().getPlayer(arg);
/* 81 */       if (p == null)
/*    */       {
/* 83 */         player.sendMessage("[Waypoint] Player " + subc + " is not online.");
/* 84 */         return true;
/*    */       }
/* 86 */       if (target == null)
/*    */       {
/* 88 */         player.sendMessage("[Waypoint] Player " + arg + " is not online.");
/* 89 */         return true;
/*    */       }
/* 91 */       Location l = target.getLocation();
/* 92 */       p.teleport(l);
/* 93 */       p.sendMessage("[Waypoint] You have been teleported by " + player.getName().toString() + ".");
/* 94 */       return true;
/*    */     }
/* 96 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.Teleport
 * JD-Core Version:    0.6.0
 */