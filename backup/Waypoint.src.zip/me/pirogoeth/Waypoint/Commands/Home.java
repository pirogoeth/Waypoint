/*     */ package me.pirogoeth.Waypoint.Commands;
/*     */ 
/*     */ import me.pirogoeth.Waypoint.Util.Command;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.MinorUtils;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ class Home extends Command
/*     */ {
/*     */   public Configuration home;
/*     */   public Configuration main;
/*     */ 
/*     */   public Home(Waypoint instance)
/*     */   {
/*  22 */     super(instance);
/*  23 */     this.main = Config.getMain();
/*  24 */     this.home = Config.getHome();
/*     */     try {
/*  26 */       setCommand("home");
/*  27 */       addAlias("wphome");
/*  28 */       register();
/*     */     } catch (CommandException e) {
/*  30 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/*  37 */     if (!this.registered) {
/*  38 */       throw new CommandException("Command is not registered.");
/*     */     }
/*  40 */     if (!Permission.has(player, "waypoint.home")) {
/*  41 */       player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  42 */       return true;
/*     */     }
/*  44 */     String subc = "";
/*     */     try {
/*  46 */       subc = args[0];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*  49 */       if (this.home.getProperty(MinorUtils.HomeNodeChomp(player, player.getWorld(), "coord.X")) != null)
/*     */       {
/*  51 */         World w = player.getWorld();
/*  52 */         double x = ((Double)this.home.getProperty(MinorUtils.HomeNodeChomp(player, w, "coord.X"))).doubleValue();
/*  53 */         double y = ((Double)this.home.getProperty(MinorUtils.HomeNodeChomp(player, w, "coord.Y"))).doubleValue();
/*  54 */         double z = ((Double)this.home.getProperty(MinorUtils.HomeNodeChomp(player, w, "coord.Z"))).doubleValue();
/*  55 */         Location l = new Location(w, x, y, z);
/*  56 */         player.setCompassTarget(l);
/*  57 */         player.teleport(l);
/*  58 */         player.sendMessage(ChatColor.GREEN + "Welcome home, " + player.getName().toString() + ".");
/*  59 */         return true;
/*     */       }
/*  61 */       if (this.home.getProperty(MinorUtils.HomeNodeChomp(player, player.getWorld(), "coord.X")) == null)
/*     */       {
/*  63 */         World w = player.getWorld();
/*  64 */         this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "coord.X"), Double.valueOf(player.getLocation().getX()));
/*  65 */         this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "coord.Y"), Double.valueOf(player.getLocation().getY()));
/*  66 */         this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "coord.Z"), Double.valueOf(player.getLocation().getZ()));
/*  67 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] Your home point for world " + w.getName().toString() + " was not set, so it was automatically set to the point you are currently at now.");
/*  68 */         this.home.save();
/*  69 */         return true;
/*     */       }
/*     */     }
/*  72 */     subc = subc.toLowerCase().toString();
/*  73 */     if (subc.equalsIgnoreCase("set"))
/*     */     {
/*  75 */       World w = player.getWorld();
/*  76 */       if (!Permission.has(player, "waypoint.home.set")) {
/*  77 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  78 */         return true;
/*     */       }
/*  80 */       this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "world"), player.getWorld().getName().toString());
/*  81 */       this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "coord.X"), Double.valueOf(player.getLocation().getX()));
/*  82 */       this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "coord.Y"), Double.valueOf(player.getLocation().getY()));
/*  83 */       this.home.setProperty(MinorUtils.HomeNodeChomp(player, w, "coord.Z"), Double.valueOf(player.getLocation().getZ()));
/*  84 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] Your home location has been set.");
/*  85 */       this.home.save();
/*  86 */       return true;
/*     */     }
/*  88 */     if (subc.equalsIgnoreCase("help"))
/*     */     {
/*  90 */       player.sendMessage(ChatColor.BLUE + "Waypoint, version " + this.plugin.getDescription().getVersion());
/*  91 */       player.sendMessage(ChatColor.GREEN + "/home:");
/*  92 */       player.sendMessage(ChatColor.RED + "   with args, will teleport you to your home.");
/*  93 */       player.sendMessage(ChatColor.RED + "   set - sets your home to the location you are currently standing at.");
/*  94 */       player.sendMessage(ChatColor.GREEN + "ways to set your home:");
/*  95 */       if (this.main.getProperty("home.set_home_at_bed") == "true") player.sendMessage(ChatColor.RED + "getting into a bed will set your home to the position of that bed.");
/*  96 */       player.sendMessage(ChatColor.RED + "typing /home without having a home already set.");
/*  97 */       player.sendMessage(ChatColor.RED + "typing /home set.");
/*  98 */       return true;
/*     */     }
/* 100 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Commands.Home
 * JD-Core Version:    0.6.0
 */