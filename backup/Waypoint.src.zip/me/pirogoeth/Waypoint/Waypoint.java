/*     */ package me.pirogoeth.Waypoint;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Commands.CommandHandler;
/*     */ import me.pirogoeth.Waypoint.Core.Links;
/*     */ import me.pirogoeth.Waypoint.Core.Spawn;
/*     */ import me.pirogoeth.Waypoint.Core.Warps;
/*     */ import me.pirogoeth.Waypoint.Core.Worlds;
/*     */ import me.pirogoeth.Waypoint.Events.BlockEventListener;
/*     */ import me.pirogoeth.Waypoint.Events.PlayerEventListener;
/*     */ import me.pirogoeth.Waypoint.Util.AutoUpdate;
/*     */ import me.pirogoeth.Waypoint.Util.CommandException;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Util.Registry;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event.Priority;
/*     */ import org.bukkit.event.Event.Type;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class Waypoint extends JavaPlugin
/*     */ {
/*     */   public Permission permissions;
/*  43 */   public Config config = new Config(this);
/*     */ 
/*  46 */   Logger log = Logger.getLogger("Minecraft");
/*     */ 
/*  48 */   public final Registry registry = new Registry(this);
/*     */ 
/*  50 */   public final Spawn spawnManager = new Spawn(this);
/*  51 */   public final Warps warpManager = new Warps(this);
/*  52 */   public final Worlds worldManager = new Worlds(this);
/*  53 */   public final Links linkManager = new Links(this);
/*     */ 
/*  55 */   public final CommandHandler commandHandler = new CommandHandler(this);
/*     */ 
/*  57 */   private final PlayerEventListener playerListener = new PlayerEventListener(this);
/*  58 */   private final BlockEventListener blockListener = new BlockEventListener(this);
/*     */ 
/*  60 */   private final AutoUpdate updateManager = new AutoUpdate(this);
/*     */ 
/*     */   public void onEnable()
/*     */   {
/*  65 */     Config.load();
/*     */ 
/*  67 */     getServer().getPluginManager().registerEvent(Event.Type.PLAYER_BED_ENTER, this.playerListener, Event.Priority.Normal, this);
/*  68 */     getServer().getPluginManager().registerEvent(Event.Type.PLAYER_INTERACT, this.playerListener, Event.Priority.Normal, this);
/*     */ 
/*  70 */     getServer().getPluginManager().registerEvent(Event.Type.SIGN_CHANGE, this.blockListener, Event.Priority.Normal, this);
/*  71 */     getServer().getPluginManager().registerEvent(Event.Type.BLOCK_BREAK, this.blockListener, Event.Priority.High, this);
/*     */ 
/*  73 */     this.permissions = new Permission(this);
/*  74 */     this.log.info("[Waypoint] Enabled version " + getDescription().getVersion());
/*  75 */     Config.save();
/*     */ 
/*  77 */     this.updateManager.doUpdate();
/*     */ 
/*  79 */     this.warpManager.LoadGroups();
/*     */ 
/*  81 */     this.worldManager.LoadWorlds();
/*     */   }
/*     */   public void onDisable() {
/*  84 */     this.updateManager.finalise();
/*  85 */     this.log.info("[Waypoint] Disabled version " + getDescription().getVersion());
/*     */   }
/*     */   public File fileGet() {
/*  88 */     return getFile();
/*     */   }
/*     */ 
/*     */   public boolean onCommand(CommandSender sender, org.bukkit.command.Command cmd, String cmdlabel, String[] args)
/*     */   {
/*  97 */     if (sender.getClass().getName().toString() == "org.bukkit.craftbukkit.command.ColouredConsoleSender")
/*     */     {
/* 100 */       sender.sendMessage("[Waypoint] You need to be a player to use this plugin.");
/* 101 */       return true;
/*     */     }
/*     */ 
/* 112 */     Player player = (Player)sender;
/* 113 */     me.pirogoeth.Waypoint.Util.Command command = this.registry.process(cmdlabel);
/* 114 */     if (command == null)
/* 115 */       return true;
/*     */     try {
/* 117 */       return command.run(player, args);
/*     */     } catch (CommandException e) {
/* 119 */       e.printStackTrace();
/* 120 */     }return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Waypoint
 * JD-Core Version:    0.6.0
 */