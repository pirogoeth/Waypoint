/*     */ package me.pirogoeth.Waypoint.Core;
/*     */ 
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.block.Sign;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ public class Links
/*     */ {
/*     */   public Waypoint plugin;
/*  26 */   public Logger log = Logger.getLogger("Minecraft");
/*     */   protected Permission permission;
/*     */   public Config config;
/*     */   public Configuration links;
/*     */ 
/*     */   public Links(Waypoint instance)
/*     */   {
/*  32 */     this.plugin = instance;
/*  33 */     this.config = this.plugin.config;
/*  34 */     this.permission = this.plugin.permissions;
/*  35 */     this.links = Config.getLinks(); } 
/*  39 */   public void CreateLink(Player player, Block sign_b, String[] lines) { BlockState sign_st = sign_b.getState();
/*  40 */     Sign sign = (Sign)sign_b.getState();
/*     */ 
/*  42 */     sign.update();
/*     */     String network;
/*     */     String name;
/*     */     String target;
/*     */     try { network = lines[1];
/*  48 */       network = network.split("\\:")[1];
/*  49 */       name = lines[2];
/*     */       try {
/*  51 */         target = lines[3];
/*     */       }
/*     */       catch (ArrayIndexOutOfBoundsException e)
/*     */       {
/*  55 */         target = null;
/*     */       }
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e)
/*     */     {
/*  60 */       int id = new Integer("63").intValue();
/*  61 */       sign.getBlock().setTypeId(0);
/*  62 */       ItemStack sign_d = new ItemStack(id);
/*  63 */       sign.getBlock().getLocation().getWorld().dropItemNaturally(sign.getBlock().getLocation(), sign_d);
/*  64 */       player.sendMessage(ChatColor.RED + "[Waypoint] Incorrect sign syntax.");
/*     */ 
/*  66 */       e.printStackTrace();
/*  67 */       return;
/*     */     }
/*  69 */     Location sign_l = sign.getBlock().getLocation();
/*  70 */     if (this.links.getProperty(String.format("links.%s.%s", new Object[] { network, name })) != null)
/*     */     {
/*  72 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] A sign in the network " + network + " already exists by this name.");
/*  73 */       return;
/*     */     }
/*  75 */     if (this.links.getProperty(String.format("links.%s.%s", new Object[] { network, name })) == null)
/*     */     {
/*  77 */       this.links.setProperty(String.format("links.%s.%s", new Object[] { network, name }), "");
/*  78 */       this.links.setProperty(String.format("links.%s.%s.coord.X", new Object[] { network, name }), Double.valueOf(sign_l.getX()));
/*  79 */       this.links.setProperty(String.format("links.%s.%s.coord.Y", new Object[] { network, name }), Double.valueOf(sign_l.getY()));
/*  80 */       this.links.setProperty(String.format("links.%s.%s.coord.Z", new Object[] { network, name }), Double.valueOf(sign_l.getZ()));
/*  81 */       this.links.setProperty(String.format("links.%s.%s.world", new Object[] { network, name }), sign_l.getWorld().getName().toString());
/*  82 */       if (target != null)
/*     */       {
/*  84 */         this.links.setProperty(String.format("links.%s.%s.target", new Object[] { network, name }), target);
/*     */       }
/*     */       else
/*     */       {
/*  89 */         this.links.setProperty(String.format("links.%s.%s.target", new Object[] { network, name }), null);
/*     */       }
/*  91 */       this.links.save();
/*  92 */       player.sendMessage(ChatColor.GREEN + String.format("[Waypoint] Sign %s has been created in network %s.", new Object[] { name, network }));
/*  93 */       return;
/*     */     } } 
/*     */   public void PlayerBetweenNetwork(Player player, Sign sign, String[] lines) {
/*  98 */     String network = lines[1].split("\\:")[1];
/*  99 */     String name = lines[2];
/*     */     String target;
/*     */     try {
/* 102 */       target = lines[3];
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e)
/*     */     {
/* 106 */       target = null;
/*     */     }
/* 108 */     if ((network == null) || (name == null) || (target == null))
/*     */     {
/* 111 */       return;
/*     */     }
/* 113 */     if ((network != null) && (name != null) && (target == null))
/*     */     {
/* 116 */       return;
/*     */     }
/* 118 */     if (this.links.getProperty(String.format("links.%s.%s.world", new Object[] { network, target })) == null)
/*     */     {
/* 120 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] The target listed on the sign does not exist.");
/* 121 */       sign.setLine(3, ChatColor.RED + target);
/* 122 */       sign.update();
/* 123 */       return;
/*     */     }
/* 125 */     if (this.links.getProperty(String.format("links.%s.%s.world", new Object[] { network, target })) != null)
/*     */     {
/* 127 */       double target_x = Double.valueOf(this.links.getDouble(String.format("links.%s.%s.coord.X", new Object[] { network, target }), 1.0D)).doubleValue();
/* 128 */       double target_y = Double.valueOf(this.links.getDouble(String.format("links.%s.%s.coord.Y", new Object[] { network, target }), 90.0D)).doubleValue();
/* 129 */       double target_z = Double.valueOf(this.links.getDouble(String.format("links.%s.%s.coord.Z", new Object[] { network, target }), 1.0D)).doubleValue();
/* 130 */       World target_w = this.plugin.getServer().getWorld(this.links.getString(String.format("links.%s.%s.world", new Object[] { network, target })));
/* 131 */       Location target_l = new Location(target_w, target_x, target_y, target_z);
/* 132 */       player.teleport(target_l);
/* 133 */       player.sendMessage(ChatColor.GREEN + "[Waypoint] You have been teleported through the network " + ChatColor.LIGHT_PURPLE + network + ChatColor.GREEN + " to sign " + ChatColor.LIGHT_PURPLE + target + ChatColor.LIGHT_PURPLE + ".");
/* 134 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void DeleteSign(Sign sign, String[] lines)
/*     */   {
/* 140 */     if (lines[0] == null)
/*     */     {
/* 144 */       return;
/*     */     }
/* 146 */     if (lines[0].equalsIgnoreCase("[Waypoint]"))
/*     */     {
/* 148 */       String network = lines[1].split("\\:")[1];
/* 149 */       String name = lines[2];
/* 150 */       this.links.removeProperty(String.format("links.%s.%s", new Object[] { network, name }));
/* 151 */       Location sign_l = sign.getBlock().getLocation();
/* 152 */       int id = new Integer("63").intValue();
/* 153 */       ItemStack sign_d = new ItemStack(id);
/* 154 */       sign.getBlock().setTypeId(0);
/* 155 */       sign_l.getWorld().dropItemNaturally(sign_l, sign_d);
/* 156 */       return;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Core.Links
 * JD-Core Version:    0.6.0
 */