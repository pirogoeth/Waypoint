/*    */ package me.pirogoeth.Waypoint.Core;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.logging.Logger;
/*    */ import me.pirogoeth.Waypoint.Util.Config;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ public class Spawn
/*    */ {
/*    */   public static Waypoint plugin;
/*    */   public static Config c;
/*    */   public static Configuration config;
/* 18 */   Logger log = Logger.getLogger("Minecraft");
/*    */ 
/*    */   public Spawn(Waypoint instance) {
/* 21 */     plugin = instance;
/* 22 */     c = plugin.config;
/* 23 */     config = Config.getSpawn();
/*    */   }
/*    */ 
/*    */   public static String SNodeChomp(World world, String subnode) {
/* 27 */     String a = "spawn." + world.getName() + "." + subnode;
/* 28 */     return a;
/*    */   }
/*    */ 
/*    */   public void ConfigWriteSpawnLocations() {
/* 32 */     List w = plugin.getServer().getWorlds();
/* 33 */     Iterator wIter = w.iterator();
/* 34 */     while (wIter.hasNext())
/*    */     {
/* 36 */       World tw = (World)wIter.next();
/* 37 */       Location l = tw.getSpawnLocation();
/* 38 */       config.setProperty(SNodeChomp(tw, "coord.X"), Double.valueOf(l.getX()));
/* 39 */       config.setProperty(SNodeChomp(tw, "coord.Y"), Double.valueOf(l.getY()));
/* 40 */       config.setProperty(SNodeChomp(tw, "coord.Z"), Double.valueOf(l.getZ()));
/* 41 */       this.log.info("[Waypoint] Wrote spawn info for world: " + tw.getName().toString());
/* 42 */       config.save();
/*    */     }
/* 44 */     this.log.info("[Waypoint] Wrote all world spawn locations.");
/*    */   }
/*    */ 
/*    */   public void SetSpawnFromCoord(World world, double x, double y, double z)
/*    */   {
/* 49 */     world.setSpawnLocation((int)x, (int)y, (int)z);
/* 50 */     SaveWorldSpawnLocation(world);
/* 51 */     world.save();
/*    */   }
/*    */ 
/*    */   public void SetSpawnFromPlayer(World world, Player player)
/*    */   {
/* 56 */     double x = player.getLocation().getX();
/* 57 */     double y = player.getLocation().getY();
/* 58 */     double z = player.getLocation().getZ();
/* 59 */     world.setSpawnLocation((int)x, (int)y, (int)z);
/* 60 */     SaveWorldSpawnLocation(world);
/* 61 */     world.save();
/*    */   }
/*    */ 
/*    */   public void SaveWorldSpawnLocation(World world)
/*    */   {
/* 66 */     Location l = world.getSpawnLocation();
/* 67 */     double x = l.getX();
/* 68 */     double y = l.getY();
/* 69 */     double z = l.getZ();
/* 70 */     config.setProperty(SNodeChomp(world, "coord.X"), Double.valueOf(x));
/* 71 */     config.setProperty(SNodeChomp(world, "coord.Y"), Double.valueOf(y));
/* 72 */     config.setProperty(SNodeChomp(world, "coord.Z"), Double.valueOf(z));
/* 73 */     config.save();
/* 74 */     this.log.info("[Waypoint] Forced save of spawn location for world: " + world.getName().toString());
/*    */   }
/*    */ 
/*    */   public void LoadWorldSpawnLocation(World world)
/*    */   {
/*    */     try {
/* 80 */       double x = ((Double)config.getProperty(SNodeChomp(world, "coord.X"))).doubleValue();
/* 81 */       double y = ((Double)config.getProperty(SNodeChomp(world, "coord.Y"))).doubleValue();
/* 82 */       double z = ((Double)config.getProperty(SNodeChomp(world, "coord.Z"))).doubleValue();
/* 83 */       world.setSpawnLocation((int)x, (int)y, (int)z);
/* 84 */       world.save();
/* 85 */       this.log.info("[Waypoint] Forced reload of spawn location for " + world.getName().toString() + " to location " + x + "," + y + "," + z);
/*    */     } catch (NullPointerException e) {
/* 87 */       this.log.info("[Waypoint] Could not reload spawn location for " + world.getName().toString());
/*    */     }
/*    */   }
/*    */ 
/*    */   public void SendPlayerToSpawn(World world, Player player)
/*    */   {
/* 93 */     Location l = world.getSpawnLocation();
/* 94 */     player.teleport(l);
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Core.Spawn
 * JD-Core Version:    0.6.0
 */