/*      */ package me.pirogoeth.Waypoint.Core;
/*      */ 
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.logging.Logger;
/*      */ import me.pirogoeth.Waypoint.Util.Config;
/*      */ import me.pirogoeth.Waypoint.Util.Permission;
/*      */ import me.pirogoeth.Waypoint.Waypoint;
/*      */ import org.bukkit.ChatColor;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Server;
/*      */ import org.bukkit.World;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.entity.Vehicle;
/*      */ import org.bukkit.plugin.PluginDescriptionFile;
/*      */ import org.bukkit.util.config.Configuration;
/*      */ import org.bukkit.util.config.ConfigurationNode;
/*      */ 
/*      */ public class Parser
/*      */ {
/*      */   public static Waypoint plugin;
/*      */   public static Config c;
/*      */   public static Configuration main;
/*      */   public static Configuration users;
/*      */   public static Configuration home;
/*      */   public static Configuration warp;
/*      */   public static Permission permissions;
/*   29 */   public static Logger log = Logger.getLogger("Minecraft");
/*      */ 
/*      */   public Parser(Waypoint instance) {
/*   32 */     plugin = instance;
/*   33 */     c = plugin.config;
/*   34 */     users = Config.getUsers();
/*   35 */     permissions = plugin.permissions;
/*   36 */     home = Config.getHome();
/*   37 */     main = Config.getMain();
/*   38 */     warp = Config.getWarp();
/*      */   }
/*      */ 
/*      */   public static String BaseNodeChomp(Player p, String node) {
/*   42 */     String a = "users." + p.getName().toString() + "." + node;
/*   43 */     return a;
/*      */   }
/*      */ 
/*      */   public static String UserNodeChomp(Player p, String targetname, String sub) {
/*   47 */     String a = "users." + p.getName().toString() + "." + targetname + "." + sub;
/*   48 */     return a;
/*      */   }
/*      */ 
/*      */   public static String HomeNodeChomp(Player p, World world, String sub) {
/*   52 */     String a = "home." + p.getName().toString() + "." + world.getName().toString() + "." + sub;
/*   53 */     return a;
/*      */   }
/*      */ 
/*      */   public static String InviteNodeChomp(Player p, String node) {
/*   57 */     String a = "invites." + p.getName().toString() + "." + node;
/*   58 */     return a;
/*      */   }
/*      */ 
/*      */   public static void TransferNode(String path, ConfigurationNode node) {
/*   62 */     Map a = node.getAll();
/*   63 */     for (Map.Entry entry : a.entrySet())
/*      */     {
/*   65 */       users.setProperty(path + "." + (String)entry.getKey(), entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean CheckPointExists(Player p, String point)
/*      */   {
/*   73 */     String a = "users." + p.getName().toString() + "." + point;
/*   74 */     if (users.getProperty(a + ".coord") == null)
/*      */     {
/*   76 */       return false;
/*      */     }
/*      */ 
/*   79 */     return users.getProperty(a + ".coord") != null;
/*      */   }
/*      */ 
/*      */   public static boolean CommandParser(Player player, String command, String[] args)
/*      */   {
/*   86 */     if ((command.equalsIgnoreCase("wp")) || (command.equalsIgnoreCase("waypoint")))
/*      */     {
/*   88 */       String subc = "";
/*      */       try {
/*   90 */         subc = args[0];
/*      */       }
/*      */       catch (ArrayIndexOutOfBoundsException e) {
/*   93 */         player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*   94 */         return true;
/*      */       }
/*   96 */       subc = subc.toLowerCase().toString();
/*   97 */       String arg = null;
/*      */       try {
/*   99 */         arg = args[1];
/*      */       }
/*      */       catch (ArrayIndexOutOfBoundsException e) {
/*  102 */         arg = null;
/*      */       }
/*  104 */       if (subc.equalsIgnoreCase("add"))
/*      */       {
/*  106 */         if (arg == null) player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*  107 */         if (!Permission.has(player, "waypoint.basic.add")) {
/*  108 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  109 */           return true;
/*      */         }
/*  111 */         if (users.getProperty(UserNodeChomp(player, arg, "world")) != null)
/*      */         {
/*  113 */           player.sendMessage("[Waypoint] Point '" + arg + "' already exists!");
/*  114 */           return true;
/*      */         }
/*      */ 
/*  117 */         users.setProperty(UserNodeChomp(player, arg, "coord.X"), Double.valueOf(player.getLocation().getX()));
/*  118 */         users.setProperty(UserNodeChomp(player, arg, "coord.Y"), Double.valueOf(player.getLocation().getY()));
/*  119 */         users.setProperty(UserNodeChomp(player, arg, "coord.Z"), Double.valueOf(player.getLocation().getZ()));
/*      */ 
/*  123 */         users.setProperty(UserNodeChomp(player, arg, "world"), player.getLocation().getWorld().getName().toString());
/*  124 */         users.save();
/*  125 */         player.sendMessage(ChatColor.GREEN + "[Waypoint] Set point '" + arg + "' in world '" + player.getLocation().getWorld().getName().toString() + "'.");
/*  126 */         return true;
/*      */       }
/*  128 */       if ((subc.equalsIgnoreCase("del")) || (subc.equalsIgnoreCase("delete")) || (subc.equalsIgnoreCase("remove")))
/*      */       {
/*  130 */         if (arg == null) player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*  131 */         if (!Permission.has(player, "waypoint.basic.delete")) {
/*  132 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  133 */           return true;
/*      */         }
/*  135 */         if (users.getProperty(UserNodeChomp(player, arg, "world")) == null)
/*      */         {
/*  137 */           player.sendMessage(ChatColor.RED + "[Waypoint] Point '" + arg + "' does not exist!");
/*  138 */           return true;
/*      */         }
/*  140 */         users.removeProperty("users." + player.getName().toString() + "." + arg);
/*  141 */         player.sendMessage("[Waypoint] Point '" + arg + "' has been deleted.");
/*  142 */         users.save();
/*  143 */         return true;
/*      */       }
/*  145 */       if ((subc.equalsIgnoreCase("tp")) || (subc.equalsIgnoreCase("teleport")))
/*      */       {
/*  147 */         if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|help> [name]");
/*  148 */         if (!Permission.has(player, "waypoint.basic.teleport")) {
/*  149 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  150 */           return true;
/*      */         }
/*  152 */         if (users.getProperty(UserNodeChomp(player, arg, "world")) == null)
/*      */         {
/*  154 */           player.sendMessage(ChatColor.RED + "[Waypoint] Point '" + arg + "' does not exist!");
/*  155 */           return true;
/*      */         }
/*  157 */         World w = plugin.getServer().getWorld(users.getProperty(UserNodeChomp(player, arg, "world")).toString());
/*  158 */         double x = ((Double)users.getProperty(UserNodeChomp(player, arg, "coord.X"))).doubleValue();
/*  159 */         double y = ((Double)users.getProperty(UserNodeChomp(player, arg, "coord.Y"))).doubleValue();
/*  160 */         double z = ((Double)users.getProperty(UserNodeChomp(player, arg, "coord.Z"))).doubleValue();
/*      */ 
/*  164 */         Location l = new Location(w, x, y, z);
/*  165 */         boolean su = player.teleport(l);
/*  166 */         if (su == true)
/*      */         {
/*  168 */           player.sendMessage(ChatColor.AQUA + "[Waypoint] Successfully teleported to '" + arg + "'.");
/*  169 */           return true;
/*      */         }
/*  171 */         if (!su)
/*      */         {
/*  173 */           player.sendMessage(ChatColor.RED + "[Waypoint] Error while teleporting to '" + arg + "'.");
/*  174 */           return true;
/*      */         }
/*  176 */         return true;
/*      */       }
/*  178 */       if (subc.equalsIgnoreCase("invite"))
/*      */       {
/*  180 */         if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|invite|help> [name]");
/*  181 */         if (!Permission.has(player, "waypoint.basic.invite")) {
/*  182 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  183 */           return true;
/*      */         }String point;
/*      */         try {
/*  187 */           point = args[2];
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  190 */           player.sendMessage(ChatColor.RED + "Usage: /wp invite <playername> <point>");
/*  191 */           return true;
/*      */         }
/*  193 */         Player p = plugin.getServer().getPlayer(arg);
/*  194 */         if (p == null)
/*      */         {
/*  196 */           player.sendMessage(ChatColor.RED + "[Waypoint] Player " + arg + " is offline. Please resend the invitation when he/she is online.");
/*  197 */           return true;
/*      */         }
/*  199 */         if (!CheckPointExists(player, point))
/*      */         {
/*  201 */           player.sendMessage(ChatColor.RED + "You do not own a point named '" + point + "'.");
/*  202 */           return true;
/*      */         }
/*  204 */         ConfigurationNode node = users.getNode(BaseNodeChomp(player, point));
/*  205 */         TransferNode(InviteNodeChomp(p, point), node);
/*  206 */         p.sendMessage(ChatColor.AQUA + "[Waypoint] Player " + player.getName().toString() + " has invited you to use their waypoint '" + point + "'.");
/*  207 */         p.sendMessage(ChatColor.GREEN + "Type /wp accept " + point + " to accept their invite.");
/*  208 */         p.sendMessage(ChatColor.GREEN + "Or type /wp decline " + point + " to decline the invite.");
/*  209 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] Sent invite to " + p.getName().toString() + ".");
/*  210 */         users.save();
/*  211 */         return true;
/*      */       }
/*  213 */       if (subc.equalsIgnoreCase("accept"))
/*      */       {
/*  215 */         if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|invite|help> [name]");
/*  216 */         if (!Permission.has(player, "waypoint.basic.invite.accept")) {
/*  217 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  218 */           return true;
/*      */         }
/*  220 */         if (users.getProperty(InviteNodeChomp(player, arg)) == null)
/*      */         {
/*  222 */           player.sendMessage(ChatColor.RED + "[Waypoint] You have no point invite by that name.");
/*  223 */           return true;
/*      */         }
/*  225 */         ConfigurationNode n = users.getNode(InviteNodeChomp(player, arg));
/*  226 */         users.removeProperty(InviteNodeChomp(player, arg));
/*  227 */         TransferNode(BaseNodeChomp(player, arg), n);
/*  228 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] The point '" + arg + "' is now available in your collection.");
/*  229 */         users.save();
/*      */       }
/*  231 */       else if (subc.equalsIgnoreCase("decline"))
/*      */       {
/*  233 */         if (arg == null) player.sendMessage(ChatColor.AQUA + "Usage: /wp <add|del|tp|list|invite|help> [name]");
/*  234 */         if (!Permission.has(player, "waypoint.basic.invite.decline")) {
/*  235 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  236 */           return true;
/*      */         }
/*  238 */         if (users.getProperty(InviteNodeChomp(player, arg)) == null)
/*      */         {
/*  240 */           player.sendMessage(ChatColor.RED + "[Waypoint] You have no point invite by that name.");
/*  241 */           return true;
/*      */         }
/*  243 */         users.removeProperty(InviteNodeChomp(player, arg));
/*  244 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] The point invitation '" + arg + "' has been declined.");
/*  245 */         users.save();
/*      */       } else {
/*  247 */         if (subc.equalsIgnoreCase("list"))
/*      */         {
/*  249 */           if (!Permission.has(player, "waypoint.basic.list")) {
/*  250 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  251 */             return true;
/*      */           }
/*  253 */           if (users.getProperty("users." + player.getName().toString()) == null)
/*      */           {
/*  255 */             player.sendMessage(ChatColor.RED + "[Waypoint] You do not have any points to list.");
/*  256 */             return true;
/*      */           }
/*  258 */           player.sendMessage(ChatColor.YELLOW + "====[Waypoint] Point list:====");
/*  259 */           Map a = users.getNodes("users." + player.getName());
/*  260 */           if (a.size() == 0)
/*      */           {
/*  262 */             player.sendMessage(ChatColor.AQUA + " - No points have been created.");
/*  263 */             return true;
/*      */           }
/*  265 */           for (Map.Entry entry : a.entrySet())
/*      */           {
/*  267 */             player.sendMessage(ChatColor.GREEN + " - " + (String)entry.getKey());
/*      */           }
/*  269 */           return true;
/*      */         }
/*  271 */         if (subc.equalsIgnoreCase("test"))
/*      */         {
/*  273 */           if (!Permission.has(player, "waypoint.debug.config_node_test")) {
/*  274 */             return true;
/*      */           }
/*      */ 
/*  277 */           double x = player.getLocation().getX();
/*  278 */           double y = player.getLocation().getY();
/*  279 */           double z = player.getLocation().getZ();
/*  280 */           users.setProperty(UserNodeChomp(player, "testnode", "coord.X"), Double.valueOf(x));
/*  281 */           users.setProperty(UserNodeChomp(player, "testnode", "coord.Y"), Double.valueOf(y));
/*  282 */           users.setProperty(UserNodeChomp(player, "testnode", "coord.Z"), Double.valueOf(z));
/*  283 */           users.save();
/*  284 */           ConfigurationNode n = users.getNode(UserNodeChomp(player, "testnode", "coord"));
/*  285 */           TransferNode(UserNodeChomp(player, "testnode", "coord"), n);
/*  286 */           users.save();
/*  287 */           users.removeProperty(BaseNodeChomp(player, "testnode"));
/*  288 */           users.save();
/*  289 */           log.info("Configuration node nesting test successful.");
/*  290 */           return true;
/*      */         }
/*  292 */         if (subc.equalsIgnoreCase("help"))
/*      */         {
/*  294 */           player.sendMessage(ChatColor.BLUE + "Waypoint, version " + plugin.getDescription().getVersion());
/*  295 */           player.sendMessage(ChatColor.GREEN + "/wp:");
/*  296 */           player.sendMessage(ChatColor.RED + "   add - add a waypoint to your list.");
/*  297 */           player.sendMessage(ChatColor.RED + "   del - remove a waypoint from your list.");
/*  298 */           player.sendMessage(ChatColor.RED + "   tp - teleport to a waypoint in your list.");
/*  299 */           player.sendMessage(ChatColor.RED + "   list - list the waypoints in your list.");
/*  300 */           player.sendMessage(ChatColor.RED + "   help - this message.");
/*  301 */           return true;
/*      */         }
/*      */ 
/*  305 */         player.sendMessage("Usage: /wp <add|del|tp|list|help> [name]");
/*  306 */         return true;
/*      */       }
/*      */ 
/*      */     }
/*  312 */     else if ((command.equalsIgnoreCase("home")) || (command.equalsIgnoreCase("wphome")))
/*      */     {
/*  314 */       if (!Permission.has(player, "waypoint.home")) {
/*  315 */         player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  316 */         return true;
/*      */       }
/*  318 */       String subc = "";
/*      */       try {
/*  320 */         subc = args[0];
/*      */       }
/*      */       catch (ArrayIndexOutOfBoundsException e) {
/*  323 */         if (home.getProperty(HomeNodeChomp(player, player.getWorld(), "coord.X")) != null)
/*      */         {
/*  325 */           World w = player.getWorld();
/*  326 */           double x = ((Double)home.getProperty(HomeNodeChomp(player, w, "coord.X"))).doubleValue();
/*  327 */           double y = ((Double)home.getProperty(HomeNodeChomp(player, w, "coord.Y"))).doubleValue();
/*  328 */           double z = ((Double)home.getProperty(HomeNodeChomp(player, w, "coord.Z"))).doubleValue();
/*  329 */           Location l = new Location(w, x, y, z);
/*  330 */           player.setCompassTarget(l);
/*  331 */           player.teleport(l);
/*  332 */           player.sendMessage(ChatColor.GREEN + "Welcome home, " + player.getName().toString() + ".");
/*  333 */           return true;
/*      */         }
/*  335 */         if (home.getProperty(HomeNodeChomp(player, player.getWorld(), "coord.X")) == null)
/*      */         {
/*  337 */           World w = player.getWorld();
/*  338 */           home.setProperty(HomeNodeChomp(player, w, "coord.X"), Double.valueOf(player.getLocation().getX()));
/*  339 */           home.setProperty(HomeNodeChomp(player, w, "coord.Y"), Double.valueOf(player.getLocation().getY()));
/*  340 */           home.setProperty(HomeNodeChomp(player, w, "coord.Z"), Double.valueOf(player.getLocation().getZ()));
/*  341 */           player.sendMessage(ChatColor.AQUA + "[Waypoint] Your home point for world " + w.getName().toString() + " was not set, so it was automatically set to the point you are currently at now.");
/*  342 */           home.save();
/*  343 */           return true;
/*      */         }
/*      */       }
/*  346 */       subc = subc.toLowerCase().toString();
/*  347 */       if (subc.equalsIgnoreCase("set"))
/*      */       {
/*  349 */         World w = player.getWorld();
/*  350 */         if (!Permission.has(player, "waypoint.home.set")) {
/*  351 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  352 */           return true;
/*      */         }
/*  354 */         home.setProperty(HomeNodeChomp(player, w, "world"), player.getWorld().getName().toString());
/*  355 */         home.setProperty(HomeNodeChomp(player, w, "coord.X"), Double.valueOf(player.getLocation().getX()));
/*  356 */         home.setProperty(HomeNodeChomp(player, w, "coord.Y"), Double.valueOf(player.getLocation().getY()));
/*  357 */         home.setProperty(HomeNodeChomp(player, w, "coord.Z"), Double.valueOf(player.getLocation().getZ()));
/*  358 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] Your home location has been set.");
/*  359 */         home.save();
/*  360 */         return true;
/*      */       }
/*  362 */       if (subc.equalsIgnoreCase("help"))
/*      */       {
/*  364 */         player.sendMessage(ChatColor.BLUE + "Waypoint, version " + plugin.getDescription().getVersion());
/*  365 */         player.sendMessage(ChatColor.GREEN + "/home:");
/*  366 */         player.sendMessage(ChatColor.RED + "   with args, will teleport you to your home.");
/*  367 */         player.sendMessage(ChatColor.RED + "   set - sets your home to the location you are currently standing at.");
/*  368 */         player.sendMessage(ChatColor.GREEN + "ways to set your home:");
/*  369 */         if (main.getProperty("home.set_home_at_bed") == "true") player.sendMessage(ChatColor.RED + "getting into a bed will set your home to the position of that bed.");
/*  370 */         player.sendMessage(ChatColor.RED + "typing /home without having a home already set.");
/*  371 */         player.sendMessage(ChatColor.RED + "typing /home set.");
/*  372 */         return true;
/*      */       }
/*      */     } else {
/*  375 */       if ((command.equalsIgnoreCase("setspawn")) || (command.equalsIgnoreCase("wpsetspawn")))
/*      */       {
/*  377 */         if (!Permission.has(player, "waypoint.admin.spawn.set")) {
/*  378 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  379 */           return true;
/*      */         }
/*  381 */         String subc = "";
/*  382 */         World w = player.getWorld();
/*  383 */         plugin.spawnManager.SendPlayerToSpawn(w, player);
/*  384 */         player.sendMessage(ChatColor.AQUA + "[Waypoint] Spawn for world " + player.getWorld().getName() + " has been set.");
/*  385 */         return true;
/*      */       }
/*  387 */       if ((command.equalsIgnoreCase("spawn")) || (command.equalsIgnoreCase("wpspawn")))
/*      */       {
/*  389 */         if (!Permission.has(player, "waypoint.spawn")) {
/*  390 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  391 */           return true;
/*      */         }
/*  393 */         String subc = "";
/*      */         try {
/*  395 */           subc = args[0];
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  398 */           World w = player.getWorld();
/*  399 */           plugin.spawnManager.SendPlayerToSpawn(w, player);
/*  400 */           return true;
/*      */         }
/*  402 */         World w = plugin.getServer().getWorld(subc);
/*  403 */         if (w == null)
/*      */         {
/*  405 */           player.sendMessage("[Waypoint] World '" + subc + "' does not exist.");
/*  406 */           return true;
/*      */         }
/*  408 */         plugin.spawnManager.SendPlayerToSpawn(w, player);
/*  409 */         return true;
/*      */       }
/*  411 */       if ((command.equalsIgnoreCase("spawnadmin")) || (command.equalsIgnoreCase("wpspawnadmin")))
/*      */       {
/*  413 */         if (!Permission.has(player, "waypoint.admin.spawn")) {
/*  414 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  415 */           return true;
/*      */         }
/*  417 */         String subc = "";
/*      */         try {
/*  419 */           subc = args[0];
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  422 */           player.sendMessage("Usage: /spawnadmin <save|load;set> <world>");
/*  423 */           return true;
/*      */         }
/*  425 */         subc = subc.toLowerCase().toString();
/*  426 */         String arg = null;
/*      */         try {
/*  428 */           arg = args[1];
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  431 */           arg = null;
/*      */         }
/*  433 */         if (subc.equalsIgnoreCase("save"))
/*      */         {
/*  435 */           if (!Permission.has(player, "waypoint.admin.spawn.save")) {
/*  436 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  437 */             return true;
/*      */           }
/*  439 */           if (arg == null)
/*      */           {
/*  441 */             World w = plugin.getServer().getWorld(player.getWorld().getName().toString());
/*  442 */             plugin.spawnManager.SaveWorldSpawnLocation(w);
/*  443 */             player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly saved spawn point for world: " + w.getName().toString());
/*  444 */             return true;
/*      */           }
/*  446 */           World w = plugin.getServer().getWorld(arg);
/*  447 */           if (w == null) {
/*  448 */             player.sendMessage(ChatColor.RED + "[Waypoint] Invalid world: " + arg); return true;
/*  449 */           }plugin.spawnManager.SaveWorldSpawnLocation(w);
/*  450 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly saved spawn point for world: " + w.getName().toString());
/*  451 */           return true;
/*      */         }
/*  453 */         if (subc.equalsIgnoreCase("load"))
/*      */         {
/*  455 */           if (!Permission.has(player, "waypoint.admin.spawn.load")) {
/*  456 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  457 */             return true;
/*      */           }
/*  459 */           if (arg == null)
/*      */           {
/*  461 */             plugin.spawnManager.LoadWorldSpawnLocation(player.getWorld());
/*  462 */             player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly reloaded spawn point for world: " + player.getWorld().getName().toString());
/*  463 */             return true;
/*      */           }
/*  465 */           plugin.spawnManager.LoadWorldSpawnLocation(player.getWorld());
/*  466 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] Forcibly reloaded spawn point for world: " + player.getWorld().getName().toString());
/*  467 */           return true;
/*      */         }
/*  469 */         if (subc.equalsIgnoreCase("set"))
/*      */         {
/*  471 */           if (!Permission.has(player, "waypoint.admin.spawn.set")) {
/*  472 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  473 */             return true;
/*      */           }
/*  475 */           plugin.spawnManager.SetSpawnFromPlayer(player.getWorld(), player);
/*  476 */           player.getWorld().save();
/*  477 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] Set spawn point for world: " + player.getWorld().getName());
/*  478 */           return true;
/*      */         }
/*      */       }
/*  481 */       else if ((command.equalsIgnoreCase("tp")) || (command.equalsIgnoreCase("wptp")))
/*      */       {
/*  483 */         if (!Permission.has(player, "waypoint.teleport.teleport")) {
/*  484 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  485 */           return true;
/*      */         }
/*  487 */         String subc = "";
/*      */         try {
/*  489 */           subc = args[0];
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  492 */           player.sendMessage("Usage: /tp <target> [user]");
/*  493 */           return true;
/*      */         }
/*      */ 
/*  498 */         String arg = null;
/*      */         try {
/*  500 */           arg = args[1];
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  503 */           arg = null;
/*      */         }
/*  505 */         if (arg == null)
/*      */         {
/*  507 */           Player target = plugin.getServer().getPlayer(subc);
/*  508 */           if (target == null)
/*      */           {
/*  510 */             player.sendMessage("[Waypoint] Player " + subc + " is not logged in.");
/*  511 */             return true;
/*      */           }
/*  513 */           Location l = target.getLocation();
/*  514 */           player.teleport(l);
/*  515 */           return true;
/*      */         }
/*  517 */         if (arg != null)
/*      */         {
/*  519 */           Player p = plugin.getServer().getPlayer(subc);
/*  520 */           Player target = plugin.getServer().getPlayer(arg);
/*  521 */           if (p == null)
/*      */           {
/*  523 */             player.sendMessage("[Waypoint] Player " + subc + " is not online.");
/*  524 */             return true;
/*      */           }
/*  526 */           if (target == null)
/*      */           {
/*  528 */             player.sendMessage("[Waypoint] Player " + arg + " is not online.");
/*  529 */             return true;
/*      */           }
/*  531 */           Location l = target.getLocation();
/*  532 */           p.teleport(l);
/*  533 */           p.sendMessage("[Waypoint] You have been teleported by " + player.getName().toString() + ".");
/*  534 */           return true;
/*      */         }
/*      */       }
/*  537 */       else if ((command.equalsIgnoreCase("tploc")) || (command.equalsIgnoreCase("wptploc")))
/*      */       {
/*  539 */         if (!Permission.has(player, "waypoint.teleport.location")) {
/*  540 */           player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  541 */           return true;
/*      */         }
/*  543 */         String subc = "";
/*  544 */         String arg = null;
/*      */         try {
/*  546 */           if (args.length == 1) {
/*  547 */             arg = args[0];
/*  548 */           } else if (args.length == 3) {
/*  549 */             arg = String.format("%s,%s,%s", new Object[] { args[0], args[1], args[2] });
/*      */           } else {
/*  551 */             player.sendMessage(ChatColor.BLUE + "/tploc <x,y,z|x y z>");
/*  552 */             return true;
/*      */           }
/*      */         }
/*      */         catch (ArrayIndexOutOfBoundsException e) {
/*  556 */           arg = null;
/*      */         }
/*  558 */         if (arg != null) { World w;
/*      */           double x;
/*      */           double y;
/*      */           double z;
/*      */           try { String[] d = arg.split("\\,");
/*  566 */             w = player.getLocation().getWorld();
/*  567 */             x = new Double(d[0]).doubleValue();
/*  568 */             y = new Double(d[1]).doubleValue();
/*  569 */             z = new Double(d[2]).doubleValue();
/*      */           } catch (ArrayIndexOutOfBoundsException e)
/*      */           {
/*  572 */             player.sendMessage(ChatColor.RED + "[Waypoint] Invalid Coordinates.");
/*  573 */             return true;
/*      */           }
/*  575 */           Location l = new Location(w, Double.valueOf(x).doubleValue(), Double.valueOf(y).doubleValue(), Double.valueOf(z).doubleValue());
/*  576 */           player.teleport(l);
/*  577 */           return true;
/*      */         }
/*  579 */         if (arg == null)
/*      */         {
/*  581 */           player.sendMessage(ChatColor.RED + "[Waypoint] You need to provide a set of coordinates.");
/*  582 */           return true;
/*      */         }
/*      */       } else {
/*  585 */         if ((command.equalsIgnoreCase("tphere")) || (command.equalsIgnoreCase("wptphere")))
/*      */         {
/*  587 */           if (!Permission.has(player, "waypoint.teleport.here")) {
/*  588 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  589 */             return true;
/*      */           }
/*  591 */           String subc = "";
/*      */           try {
/*  593 */             subc = args[0];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  596 */             player.sendMessage("Usage: /tp <target> [user]");
/*  597 */             return true;
/*      */           }
/*  599 */           subc = subc.toLowerCase().toString();
/*  600 */           Player target = plugin.getServer().getPlayer(subc);
/*  601 */           if (target == null)
/*      */           {
/*  603 */             player.sendMessage(ChatColor.AQUA + "[Waypoint] Player " + subc + " is not online.");
/*  604 */             return true;
/*      */           }
/*  606 */           Location l = player.getLocation();
/*  607 */           Vehicle target_veh = target.getVehicle();
/*  608 */           if (target_veh != null) target_veh.eject();
/*  609 */           target.teleport(l);
/*  610 */           target.sendMessage(ChatColor.GREEN + "[Waypoint] You have been teleported to " + player.getName().toString() + ".");
/*  611 */           return true;
/*      */         }
/*  613 */         if ((command.equalsIgnoreCase("setwarp")) || (command.equalsIgnoreCase("wpsetwarp")))
/*      */         {
/*  615 */           if (!Permission.has(player, "waypoint.warp.create")) {
/*  616 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  617 */             return true;
/*      */           }
/*  619 */           String subc = "";
/*      */           try {
/*  621 */             subc = args[0];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  624 */             player.sendMessage("Usage: /setwarp <name>");
/*  625 */             return true;
/*      */           }
/*  627 */           subc = subc.toLowerCase().toString();
/*  628 */           plugin.warpManager.CreateWarp(player, subc);
/*  629 */           player.sendMessage(ChatColor.AQUA + "[Waypoint] Warp " + subc + " has been created.");
/*  630 */           return true;
/*      */         }
/*  632 */         if ((command.equalsIgnoreCase("warpadmin")) || (command.equalsIgnoreCase("wpwarpadmin")))
/*      */         {
/*  634 */           if (!Permission.has(player, "waypoint.admin.warp"))
/*      */           {
/*  636 */             player.sendMessage(ChatColor.BLUE + "You do not have the permission to use this command.");
/*  637 */             return true;
/*      */           }
/*  639 */           String subc = "";
/*  640 */           String arg = "";
/*  641 */           String k = "";
/*  642 */           String v = "";
/*      */           try {
/*  644 */             subc = args[0];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  647 */             player.sendMessage("Usage: /warpadmin <del|set> [key] [value]");
/*  648 */             return true;
/*      */           }
/*      */ 
/*      */           try
/*      */           {
/*  653 */             arg = args[1];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  656 */             arg = null;
/*      */           }
/*      */           try {
/*  659 */             k = args[2];
/*  660 */             v = args[3];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  663 */             k = null;
/*  664 */             v = null;
/*      */           }
/*  666 */           if (subc.equalsIgnoreCase("del"))
/*      */           {
/*  668 */             if (arg == null)
/*      */             {
/*  670 */               player.sendMessage(ChatColor.RED + "/warpadmin del <warpname>");
/*  671 */               return true;
/*      */             }
/*  673 */             if (warp.getProperty(plugin.warpManager.WarpBase(arg)) == null)
/*      */             {
/*  675 */               player.sendMessage(ChatColor.RED + "[Waypoint] There is no warp by that name.");
/*  676 */               return true;
/*      */             }
/*  678 */             if (!Permission.has(player, "waypoint.admin.warp.delete"))
/*      */             {
/*  680 */               player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/*  681 */               return true;
/*      */             }
/*  683 */             plugin.warpManager.DeleteWarp(arg);
/*  684 */             player.sendMessage(ChatColor.BLUE + "[Waypoint] Warp " + arg + " has been deleted.");
/*  685 */             return true;
/*      */           }
/*  687 */           if (subc.equalsIgnoreCase("read"))
/*      */           {
/*  689 */             if (arg == null)
/*      */             {
/*  691 */               player.sendMessage(ChatColor.RED + "/warp read <warpname>");
/*  692 */               return true;
/*      */             }
/*  694 */             ConfigurationNode a = warp.getNode(plugin.warpManager.WarpBase(arg));
/*  695 */             if (a == null)
/*      */             {
/*  697 */               player.sendMessage("[Waypoint] No warp by that name.");
/*  698 */               return true;
/*      */             }
/*  700 */             player.sendMessage(ChatColor.BLUE + "[Waypoint] Metadata for warp '" + arg + "':");
/*  701 */             Map b = a.getAll();
/*  702 */             for (Map.Entry entry : b.entrySet())
/*      */             {
/*  704 */               player.sendMessage(String.format("%s  %s -> %s%s", new Object[] { ChatColor.GREEN, (String)entry.getKey(), ChatColor.BLUE, entry.getValue().toString() }));
/*      */             }
/*  706 */             return true;
/*      */           }
/*  708 */           if (subc.equalsIgnoreCase("set"))
/*      */           {
/*  710 */             if (arg == null)
/*      */             {
/*  712 */               player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/*  713 */               return true;
/*      */             }
/*  715 */             if (k == null)
/*      */             {
/*  717 */               player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/*  718 */               return true;
/*      */             }
/*  720 */             if (v == null)
/*      */             {
/*  722 */               player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/*  723 */               return true;
/*      */             }
/*      */ 
/*  735 */             String owner = (String)warp.getProperty(plugin.warpManager.WarpNode(arg, "owner"));
/*      */ 
/*  743 */             k = k.toLowerCase().toString();
/*      */ 
/*  746 */             if (warp.getProperty(plugin.warpManager.WarpNode(arg, "permission")) == null)
/*      */             {
/*  748 */               player.sendMessage(ChatColor.RED + "[Waypoint] This warp does not exist.");
/*  749 */               return true;
/*      */             }
/*  751 */             boolean f = plugin.warpManager.SetWarpProp(arg, k, v);
/*  752 */             if (!f)
/*      */             {
/*  754 */               player.sendMessage(ChatColor.RED + "[Waypoint] An error occurred while trying to set the properties of warp: " + arg);
/*  755 */               return true;
/*      */             }
/*  757 */             if (f)
/*      */             {
/*  759 */               player.sendMessage(ChatColor.GREEN + "[Waypoint] Successfully set the property '" + k + "' to '" + v + "' for warp " + arg);
/*  760 */               return true;
/*      */             }
/*  762 */             return true;
/*      */           }
/*      */         }
/*  765 */         else if ((command.equalsIgnoreCase("world")) || (command.equalsIgnoreCase("wpworld")))
/*      */         {
/*  767 */           if (!Permission.has(player, "waypoint.world")) {
/*  768 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  769 */             return true;
/*      */           }
/*  771 */           String subc = "";
/*  772 */           String arg = "";
/*      */           try {
/*  774 */             subc = args[0];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  777 */             subc = null;
/*      */           }
/*  779 */           if (subc == null)
/*      */           {
/*  781 */             String worldname = player.getLocation().getWorld().getName().toString();
/*  782 */             player.sendMessage(ChatColor.BLUE + "You are currently in world: " + worldname);
/*  783 */             String x = Double.toString(player.getLocation().getX());
/*  784 */             String y = Double.toString(player.getLocation().getY());
/*  785 */             String z = Double.toString(player.getLocation().getZ());
/*  786 */             player.sendMessage(ChatColor.BLUE + "Your current position is: " + x + "," + y + "," + z);
/*  787 */             return true;
/*      */           }
/*  789 */           if (subc.equalsIgnoreCase("list"))
/*      */           {
/*  792 */             List w = plugin.getServer().getWorlds();
/*  793 */             player.sendMessage(ChatColor.GREEN + "World List: ");
/*  794 */             Iterator i = w.iterator();
/*      */ 
/*  796 */             while (i.hasNext())
/*      */             {
/*  798 */               World wx = (World)i.next();
/*  799 */               player.sendMessage(ChatColor.GREEN + " - " + wx.getName());
/*      */             }
/*  801 */             return true;
/*      */           }
/*  803 */           if (subc.equalsIgnoreCase("import"))
/*      */           {
/*  805 */             if (!Permission.has(player, "waypoint.admin.world.import")) {
/*  806 */               player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  807 */               return true; } 
/*      */ String worldname = args[1];
/*      */             String environ;
/*      */             try { environ = args[2]; } catch (ArrayIndexOutOfBoundsException e) {
/*  813 */               environ = null;
/*  814 */             }if (environ == null)
/*      */             {
/*  816 */               player.sendMessage(ChatColor.BLUE + "[Waypoint] Please specify an environment type.");
/*  817 */               return true;
/*      */             }
/*  819 */             World wx = plugin.worldManager.Import(worldname, environ.toUpperCase());
/*  820 */             if (wx == null)
/*      */             {
/*  822 */               player.sendMessage(ChatColor.RED + "World import failed.");
/*  823 */               return true;
/*      */             }
/*  825 */             Config.getWorld().setProperty("world." + worldname + ".env", environ.toUpperCase());
/*  826 */             Config.save();
/*  827 */             player.sendMessage(String.format("%s[Waypoint] Loaded world: { %s [ENV:%s] }", new Object[] { ChatColor.GREEN, worldname, environ.toUpperCase() }));
/*  828 */             return true;
/*      */           }
/*  830 */           if (subc.equalsIgnoreCase("create"))
/*      */           {
/*  832 */             if (!Permission.has(player, "waypoint.admin.world.create")) {
/*  833 */               player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  834 */               return true; } 
/*      */ String worldname = args[1];
/*      */             String environ;
/*      */             try { environ = args[2]; } catch (ArrayIndexOutOfBoundsException e) {
/*  840 */               environ = null;
/*      */             }
/*  842 */             World wx = null;
/*      */ 
/*  852 */             if (environ == null)
/*      */             {
/*  854 */               player.sendMessage(ChatColor.BLUE + "[Waypoint] Please specify an environment type.");
/*  855 */               return true;
/*      */             }
/*      */ 
/*  867 */             wx = plugin.worldManager.Create(worldname, environ.toUpperCase());
/*  868 */             if (wx == null)
/*      */             {
/*  870 */               player.sendMessage(String.format("%s[Waypoint] Could not create world: %s", new Object[] { ChatColor.RED, worldname }));
/*  871 */               return true;
/*      */             }
/*  873 */             Config.getWorld().setProperty("world." + worldname + ".env", environ.toUpperCase());
/*  874 */             Config.save();
/*  875 */             player.sendMessage(String.format("%s[Waypoint] Successfully created world: { %s [ENV: %s] }", new Object[] { ChatColor.GREEN, worldname, environ.toUpperCase() }));
/*  876 */             return true;
/*      */           }
/*  878 */           if (subc != null)
/*      */           {
/*  880 */             World w = plugin.getServer().getWorld(subc);
/*  881 */             if (w == null)
/*      */             {
/*  883 */               player.sendMessage(ChatColor.RED + "[Waypoint] World " + subc + " does not exist.");
/*  884 */               return true;
/*      */             }
/*  886 */             if (!Permission.has(player, "waypoint.world.teleport"))
/*      */             {
/*  888 */               player.sendMessage("[Waypoint] You do not have permission to use this command.");
/*  889 */               return true;
/*      */             }
/*  891 */             Location wsl = w.getSpawnLocation();
/*  892 */             player.teleport(wsl);
/*  893 */             player.sendMessage(ChatColor.GREEN + "[Waypoint] You have been taken to the spawn of world '" + w.getName().toString() + "'.");
/*  894 */             return true;
/*      */           }
/*      */         }
/*  897 */         else if ((command.equalsIgnoreCase("warp")) || (command.equalsIgnoreCase("wpwarp")))
/*      */         {
/*  899 */           if (!Permission.has(player, "waypoint.warp")) {
/*  900 */             player.sendMessage(ChatColor.BLUE + "You do not have the permissions to use this command.");
/*  901 */             return true;
/*      */           }
/*  903 */           String subc = "";
/*  904 */           String arg = "";
/*  905 */           String k = "";
/*  906 */           String v = "";
/*      */           try {
/*  908 */             subc = args[0];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  911 */             player.sendMessage("Usage: /warp <add|del|set|list|<warp name>> [key] [value]");
/*  912 */             return true;
/*      */           }
/*  914 */           String origc = subc;
/*      */           try
/*      */           {
/*  918 */             arg = args[1];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  921 */             arg = null;
/*      */           }
/*      */           try {
/*  924 */             k = args[2];
/*  925 */             v = args[3];
/*      */           }
/*      */           catch (ArrayIndexOutOfBoundsException e) {
/*  928 */             k = null;
/*  929 */             v = null;
/*      */           }
/*  931 */           if (subc.equalsIgnoreCase("add"))
/*      */           {
/*  933 */             if (arg == null)
/*      */             {
/*  935 */               player.sendMessage(ChatColor.RED + "/warp add <warpname>");
/*  936 */               return true;
/*      */             }
/*  938 */             if (!Permission.has(player, "waypoint.warp.create"))
/*      */             {
/*  940 */               player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/*  941 */               return true;
/*      */             }
/*  943 */             plugin.warpManager.CreateWarp(player, arg);
/*  944 */             player.sendMessage(ChatColor.AQUA + "[Waypoint] Warp " + arg + " has been created.");
/*  945 */             return true;
/*      */           }
/*  947 */           if (subc.equalsIgnoreCase("del"))
/*      */           {
/*  949 */             if (arg == null)
/*      */             {
/*  951 */               player.sendMessage(ChatColor.RED + "/warp del <warpname>");
/*  952 */               return true;
/*      */             }
/*  954 */             if (warp.getProperty(plugin.warpManager.WarpBase(arg)) == null)
/*      */             {
/*  956 */               player.sendMessage(ChatColor.RED + "[Waypoint] There is no warp by that name.");
/*  957 */               return true;
/*      */             }
/*  959 */             String owner = (String)warp.getProperty(plugin.warpManager.WarpNode(arg, "owner"));
/*  960 */             if ((!Permission.has(player, "waypoint.warp.delete")) || (!owner.equals(player.getName().toString())))
/*      */             {
/*  962 */               player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/*  963 */               return true;
/*      */             }
/*  965 */             plugin.warpManager.DeleteWarp(arg);
/*  966 */             player.sendMessage(ChatColor.AQUA + "[Waypoint] Warp " + arg + " has been deleted.");
/*  967 */             return true;
/*      */           }
/*  969 */           if (subc.equalsIgnoreCase("remote"))
/*      */           {
/*  971 */             if ((arg == null) || (k == null))
/*      */             {
/*  973 */               player.sendMessage(ChatColor.RED + "/warp remote <player> <warpname>");
/*  974 */               return true;
/*      */             }
/*  976 */             if (!Permission.has(player, "waypoint.warp.remote"))
/*      */             {
/*  978 */               player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to use this command.");
/*  979 */               return true;
/*      */             }
/*  981 */             Player target = plugin.getServer().getPlayer(arg);
/*  982 */             if (target == null)
/*      */             {
/*  984 */               player.sendMessage(ChatColor.RED + "[Waypoint] Player " + arg + " is not online.");
/*  985 */               return true;
/*      */             }
/*  987 */             boolean remote = plugin.warpManager.RemoteWarp(target, player, k);
/*  988 */             return true;
/*      */           }
/*  990 */           if (subc.equalsIgnoreCase("set"))
/*      */           {
/*  992 */             if (arg == null)
/*      */             {
/*  994 */               player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/*  995 */               return true;
/*      */             }
/*  997 */             if (k == null)
/*      */             {
/*  999 */               player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 1000 */               return true;
/*      */             }
/* 1002 */             if (v == null)
/*      */             {
/* 1004 */               player.sendMessage(ChatColor.RED + "/warp set <warpname> <key> <value>");
/* 1005 */               return true;
/*      */             }
/*      */ 
/* 1017 */             String owner = (String)warp.getProperty(plugin.warpManager.WarpNode(arg, "owner"));
/* 1018 */             if (!owner.equals(player.getName().toString()))
/*      */             {
/* 1020 */               player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission modify this warp.");
/* 1021 */               return true;
/*      */             }
/*      */ 
/* 1028 */             if (warp.getProperty(plugin.warpManager.WarpNode(arg, "permission")) == null)
/*      */             {
/* 1030 */               player.sendMessage(ChatColor.RED + "[Waypoint] This warp does not exist.");
/* 1031 */               return true;
/*      */             }
/* 1033 */             boolean f = plugin.warpManager.SetWarpProp(arg, k, v);
/* 1034 */             if (!f)
/*      */             {
/* 1036 */               player.sendMessage(ChatColor.RED + "[Waypoint] An error occurred while trying to set the properties of warp: " + arg);
/* 1037 */               return true;
/*      */             }
/* 1039 */             if (f)
/*      */             {
/* 1041 */               player.sendMessage(ChatColor.GREEN + "[Waypoint] Successfully set the property '" + k + "' to '" + v + "' for warp " + arg);
/* 1042 */               return true;
/*      */             }
/* 1044 */             return true;
/*      */           }
/* 1046 */           if (subc.equalsIgnoreCase("list"))
/*      */           {
/* 1048 */             if (!Permission.has(player, "waypoint.warp.list"))
/*      */             {
/* 1050 */               player.sendMessage(ChatColor.RED + "[Waypoint] You do not have the permission to access this command.");
/* 1051 */               return true;
/*      */             }
/* 1053 */             int x = 0;
/*      */ 
/* 1055 */             Map a = warp.getNodes("warps");
/* 1056 */             if ((a == null) || (a.size() == 0))
/*      */             {
/* 1058 */               player.sendMessage(ChatColor.YELLOW + "[Waypoint] There are currently no warps to be displayed.");
/* 1059 */               return true;
/*      */             }
/* 1061 */             player.sendMessage(ChatColor.GREEN + "====[Waypoint] Warps available to you:====");
/* 1062 */             for (Map.Entry entry : a.entrySet())
/*      */             {
/* 1064 */               ConfigurationNode node = (ConfigurationNode)entry.getValue();
/* 1065 */               String warppermission = (String)node.getProperty("permission");
/* 1066 */               if (warppermission == null)
/*      */               {
/* 1068 */                 player.sendMessage(ChatColor.RED + "[Waypoint] You have not set any warp permission groups to your configuration.");
/* 1069 */                 return true;
/*      */               }
/* 1071 */               if (plugin.warpManager.checkperms(player, warppermission))
/*      */               {
/* 1073 */                 if ((!player.getWorld().toString().equals((String)node.getProperty("world"))) && (((String)Config.getMain().getProperty("warp.list_world_only")).equals("true")))
/*      */                 {
/*      */                   continue;
/*      */                 }
/*      */ 
/* 1079 */                 player.sendMessage(ChatColor.AQUA + " - " + (String)entry.getKey());
/*      */               }
/*      */ 
/* 1082 */               x++;
/*      */             }
/* 1084 */             if (x == 0)
/*      */             {
/* 1086 */               player.sendMessage(ChatColor.YELLOW + "[Waypoint] There are currently no warps to be displayed.");
/*      */             }
/* 1088 */             return true;
/*      */           }
/*      */ 
/* 1091 */           if (warp.getProperty(plugin.warpManager.WarpBase(origc)) != null)
/*      */           {
/* 1093 */             plugin.warpManager.PlayerToWarp(player, origc);
/* 1094 */             return true;
/*      */           }
/* 1096 */           if (warp.getProperty(plugin.warpManager.WarpBase(origc)) == null)
/*      */           {
/* 1098 */             player.sendMessage(ChatColor.LIGHT_PURPLE + "[Waypoint] Warp " + origc + " does not exist.");
/* 1099 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1102 */     return false;
/*      */   }
/*      */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Core.Parser
 * JD-Core Version:    0.6.0
 */