/*     */ package me.pirogoeth.Waypoint.Core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.World.Environment;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ import org.bukkit.util.config.ConfigurationNode;
/*     */ 
/*     */ public class Worlds
/*     */ {
/*     */   public Waypoint plugin;
/*  22 */   public Logger log = Logger.getLogger("Minecraft");
/*     */   protected Permission permission;
/*     */   public Config config;
/*     */ 
/*     */   public Worlds(Waypoint instance)
/*     */   {
/*  27 */     this.plugin = instance;
/*  28 */     this.config = this.plugin.config;
/*  29 */     this.permission = this.plugin.permissions;
/*     */   }
/*     */ 
/*     */   public void LoadWorlds() {
/*  33 */     Configuration world = Config.getWorld();
/*  34 */     Map worlds = world.getNodes("worlds");
/*  35 */     if (worlds == null)
/*     */     {
/*  37 */       this.log.info("[Waypoint] No worlds to be loaded.");
/*  38 */       return;
/*     */     }
/*  40 */     List worldlist = this.plugin.getServer().getWorlds();
/*  41 */     List worldnames = new ArrayList();
/*     */ 
/*  43 */     Iterator worldlist_i = worldlist.iterator();
/*  44 */     while (worldlist_i.hasNext())
/*     */     {
/*  46 */       World wx = (World)worldlist_i.next();
/*  47 */       worldnames.add(wx.getName().toString());
/*     */     }
/*     */ 
/*  53 */     for (Map.Entry entry : worlds.entrySet())
/*     */     {
/*  55 */       String worldname = (String)entry.getKey();
/*  56 */       ConfigurationNode e = (ConfigurationNode)entry.getValue();
/*  57 */       String env = e.getString("env");
/*  58 */       int mode = e.getInt("mode", 404);
/*  59 */       if (!worldnames.contains(worldname))
/*     */       {
/*  61 */         if (mode == 404) Import(worldname, env, 0); else {
/*  62 */           Import(worldname, env, mode);
/*     */         }
/*     */       }
/*     */       else
/*  66 */         this.log.info(String.format("[Waypoint] Loaded properties for world: { %s [ENV: %s(MODE:%s)] }", new Object[] { worldname, env, Integer.toString(mode) }));
/*     */     }
/*     */   }
/*     */ 
/*     */   public World Import(String worldname, String env)
/*     */   {
/*  73 */     World.Environment environment = World.Environment.valueOf(env);
/*  74 */     Configuration world = Config.getWorld();
/*  75 */     if ((new File(worldname).exists()) && (environment != null))
/*     */     {
/*  77 */       World wx = this.plugin.getServer().createWorld(worldname, environment);
/*  78 */       this.log.info(String.format("[Waypoint] Imported world: { %s [ENV:%s(MODE:%s)] }", new Object[] { worldname, env.toUpperCase(), "0" }));
/*  79 */       world.setProperty("worlds." + worldname + ".env", env.toUpperCase());
/*  80 */       world.setProperty("worlds." + worldname + ".mode", Integer.valueOf(0));
/*  81 */       world.save();
/*  82 */       return wx;
/*     */     }
/*  84 */     if (environment == null)
/*     */     {
/*  86 */       return null;
/*     */     }
/*     */ 
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */   public World Import(String worldname, String env, int mode)
/*     */   {
/*  95 */     if (mode == 404) return Import(worldname, env);
/*  96 */     if ((mode != 0) && (mode != 1)) mode = 0;
/*  97 */     World.Environment environment = World.Environment.valueOf(env);
/*  98 */     Configuration world = Config.getWorld();
/*  99 */     if ((new File(worldname).exists()) && (environment != null))
/*     */     {
/* 101 */       World wx = this.plugin.getServer().createWorld(worldname, environment);
/* 102 */       this.log.info(String.format("[Waypoint] Imported world: { %s [ENV:%s(MODE:%s)] }", new Object[] { worldname, env.toUpperCase(), Integer.toString(mode) }));
/* 103 */       world.setProperty("worlds." + worldname + ".env", env.toUpperCase());
/* 104 */       world.setProperty("worlds." + worldname + ".mode", Integer.valueOf(mode));
/* 105 */       world.save();
/* 106 */       return wx;
/*     */     }
/* 108 */     if (environment == null)
/*     */     {
/* 110 */       return null;
/*     */     }
/*     */ 
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public World Create(String worldname, String env)
/*     */   {
/* 119 */     World.Environment environment = World.Environment.valueOf(env);
/* 120 */     Configuration world = Config.getWorld();
/* 121 */     if ((!new File(worldname).exists()) && (environment != null))
/*     */     {
/* 123 */       World wx = this.plugin.getServer().createWorld(worldname, environment);
/* 124 */       this.log.info(String.format("[Waypoint] Created world: { %s [ENV:%s] }", new Object[] { worldname, env.toUpperCase(), "0" }));
/* 125 */       world.setProperty("worlds." + worldname + ".env", env.toUpperCase());
/* 126 */       world.save();
/* 127 */       return wx;
/*     */     }
/* 129 */     if (environment == null)
/*     */     {
/* 131 */       return null;
/*     */     }
/*     */ 
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */   public World Create(String worldname, String env, int mode)
/*     */   {
/* 140 */     if (mode == 404) return Create(worldname, env);
/* 141 */     if ((mode != 0) && (mode != 1)) mode = 0;
/* 142 */     World.Environment environment = World.Environment.valueOf(env);
/* 143 */     Configuration world = Config.getWorld();
/* 144 */     if ((!new File(worldname).exists()) && (environment != null))
/*     */     {
/* 146 */       World wx = this.plugin.getServer().createWorld(worldname, environment);
/* 147 */       this.log.info(String.format("[Waypoint] Created world: { %s [ENV:%s(MODE:%s)] }", new Object[] { worldname, env.toUpperCase(), Integer.toString(mode) }));
/* 148 */       world.setProperty("worlds." + worldname + ".env", env.toUpperCase());
/* 149 */       world.setProperty("worlds." + worldname + ".mode", Integer.valueOf(mode));
/* 150 */       world.save();
/* 151 */       return wx;
/*     */     }
/* 153 */     if (environment == null)
/*     */     {
/* 155 */       return null;
/*     */     }
/*     */ 
/* 159 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Core.Worlds
 * JD-Core Version:    0.6.0
 */