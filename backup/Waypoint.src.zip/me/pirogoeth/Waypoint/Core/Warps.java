/*     */ package me.pirogoeth.Waypoint.Core;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ public class Warps
/*     */ {
/*     */   public static Waypoint plugin;
/*     */   public static Config c;
/*     */   public static Configuration config;
/*     */   public static Configuration main;
/*  21 */   public static Logger log = Logger.getLogger("Minecraft");
/*     */   public List<String> groups;
/*     */ 
/*     */   public Warps(Waypoint instance)
/*     */   {
/*  25 */     plugin = instance;
/*  26 */     c = plugin.config;
/*  27 */     config = Config.getWarp();
/*  28 */     main = Config.getMain();
/*     */   }
/*     */ 
/*     */   public void LoadGroups() {
/*  32 */     this.groups = Config.getMain().getStringList("warp.permissions", null);
/*  33 */     Iterator i = this.groups.iterator();
/*  34 */     StringBuffer s = new StringBuffer((String)i.next());
/*  35 */     while (i.hasNext()) s.append(", ").append((String)i.next());
/*  36 */     log.info(String.format("[Waypoint] Warps: loaded permission groups: %s", new Object[] { s.toString() }));
/*     */   }
/*     */ 
/*     */   public String WarpNode(String warpname, String subnode)
/*     */   {
/*  41 */     String a = "warps." + warpname + "." + subnode;
/*  42 */     return a;
/*     */   }
/*     */ 
/*     */   public String WarpBase(String warpname) {
/*  46 */     String a = "warps." + warpname;
/*  47 */     return a;
/*     */   }
/*     */ 
/*     */   public boolean checkperms(Player p, String pnode) {
/*  51 */     String permission = String.format("waypoint.warp.access.%s", new Object[] { pnode });
/*  52 */     return Permission.has(p, permission);
/*     */   }
/*     */ 
/*     */   public void CreateWarp(Player p, String warpname) {
/*  56 */     Location l = p.getLocation();
/*  57 */     double x = l.getX();
/*  58 */     double y = l.getY();
/*  59 */     double z = l.getZ();
/*  60 */     String worldname = p.getWorld().getName().toString();
/*  61 */     String owner = p.getName().toString();
/*  62 */     config.setProperty(WarpNode(warpname, "coord.X"), Double.valueOf(x));
/*  63 */     config.setProperty(WarpNode(warpname, "coord.Y"), Double.valueOf(y));
/*  64 */     config.setProperty(WarpNode(warpname, "coord.Z"), Double.valueOf(z));
/*  65 */     config.setProperty(WarpNode(warpname, "world"), worldname);
/*  66 */     config.setProperty(WarpNode(warpname, "owner"), owner);
/*  67 */     String permission = (String)this.groups.get(0);
/*  68 */     config.setProperty(WarpNode(warpname, "permission"), permission);
/*  69 */     config.save();
/*     */   }
/*     */ 
/*     */   public boolean DeleteWarp(String warpname)
/*     */   {
/*  74 */     if (config.getProperty(WarpNode(warpname, "world")) == null)
/*     */     {
/*  76 */       return false;
/*     */     }
/*  78 */     config.removeProperty(WarpBase(warpname));
/*  79 */     config.save();
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean CheckGroup(String group) {
/*  84 */     return this.groups.contains(group);
/*     */   }
/*     */ 
/*     */   public boolean SetWarpProp(String warpname, String key, String value) {
/*  88 */     if (config.getProperty(WarpNode(warpname, "world")) == null)
/*     */     {
/*  90 */       return false;
/*     */     }
/*  92 */     if (((key.equalsIgnoreCase("permission")) && (CheckGroup(value))) || (key.equalsIgnoreCase("owner")))
/*     */     {
/*  94 */       config.setProperty(WarpNode(warpname, key), value);
/*  95 */       config.save();
/*  96 */       return true;
/*     */     }
/*     */ 
/* 100 */     return (!key.equalsIgnoreCase("permission")) || (CheckGroup(value));
/*     */   }
/*     */ 
/*     */   public boolean PlayerToWarp(Player p, String warpname)
/*     */   {
/* 106 */     if (config.getProperty(WarpNode(warpname, "world")) == null)
/*     */     {
/* 108 */       p.sendMessage(ChatColor.RED + "[Waypoint] Warp " + warpname + " does not exist.");
/* 109 */       return false;
/*     */     }
/* 111 */     String permission = (String)config.getProperty(WarpNode(warpname, "permission"));
/* 112 */     if (!checkperms(p, permission))
/*     */     {
/* 114 */       p.sendMessage(ChatColor.RED + "[Waypoint] You do not have permissions to access this warp.");
/* 115 */       return true;
/*     */     }
/* 117 */     String worldname = (String)config.getProperty(WarpNode(warpname, "world"));
/* 118 */     if ((!p.getWorld().toString().equals(worldname)) && (((String)Config.getMain().getProperty("warp.traverse_world_only")).equals("true")))
/*     */     {
/* 120 */       p.sendMessage(ChatColor.RED + "[Waypoint] You are not allowed to warp between worlds.");
/* 121 */       return true;
/*     */     }
/* 123 */     double x = ((Double)config.getProperty(WarpNode(warpname, "coord.X"))).doubleValue();
/* 124 */     double y = ((Double)config.getProperty(WarpNode(warpname, "coord.Y"))).doubleValue();
/* 125 */     double z = ((Double)config.getProperty(WarpNode(warpname, "coord.Z"))).doubleValue();
/* 126 */     World w = plugin.getServer().getWorld(worldname);
/* 127 */     Location l = new Location(w, x, y, z);
/* 128 */     p.teleport(l);
/*     */ 
/* 130 */     if (((String)main.getProperty("warp.warpstring_enabled")).equalsIgnoreCase("true"))
/*     */     {
/* 132 */       String warpstring = (String)main.getProperty("warp.string");
/* 133 */       if (warpstring == null)
/*     */       {
/* 136 */         log.warning("[Waypoint] Warp string is null! Please set the warp.string value in config.yml");
/* 137 */         return true;
/*     */       }
/* 139 */       warpstring = warpstring.replaceAll("%w", "" + warpname);
/* 140 */       warpstring = warpstring.replaceAll("%p", "" + p.getName().toString());
/* 141 */       p.sendMessage(String.format("%s%s", new Object[] { ChatColor.BLUE, warpstring }));
/* 142 */       return true;
/*     */     }
/* 144 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean RemoteWarp(Player target, Player sender, String warpname) {
/* 148 */     if (config.getProperty(WarpNode(warpname, "world")) == null)
/*     */     {
/* 150 */       sender.sendMessage(ChatColor.RED + "[Waypoint] Warp " + warpname + " does not exist.");
/* 151 */       return false;
/*     */     }
/* 153 */     String permission = (String)config.getProperty(WarpNode(warpname, "permission"));
/* 154 */     if (!checkperms(sender, permission))
/*     */     {
/* 156 */       sender.sendMessage(ChatColor.RED + "[Waypoint] You do not have permissions to access this warp.");
/* 157 */       return true;
/*     */     }
/* 159 */     String worldname = (String)config.getProperty(WarpNode(warpname, "world"));
/* 160 */     if ((!target.getWorld().toString().equals(worldname)) && (((String)Config.getMain().getProperty("warp.traverse_world_only")).equals("true")))
/*     */     {
/* 162 */       sender.sendMessage(ChatColor.RED + "[Waypoint] You are not allowed to warp others between worlds.");
/* 163 */       return true;
/*     */     }
/* 165 */     double x = ((Double)config.getProperty(WarpNode(warpname, "coord.X"))).doubleValue();
/* 166 */     double y = ((Double)config.getProperty(WarpNode(warpname, "coord.Y"))).doubleValue();
/* 167 */     double z = ((Double)config.getProperty(WarpNode(warpname, "coord.Z"))).doubleValue();
/* 168 */     World w = plugin.getServer().getWorld(worldname);
/* 169 */     Location l = new Location(w, x, y, z);
/* 170 */     target.teleport(l);
/* 171 */     sender.sendMessage(ChatColor.GREEN + String.format("[Waypoint] %s has been warped to %s", new Object[] { target.getName().toString(), warpname }));
/*     */ 
/* 173 */     if (((String)main.getProperty("warp.warpstring_enabled")).equalsIgnoreCase("true"))
/*     */     {
/* 175 */       String warpstring = (String)main.getProperty("warp.string");
/* 176 */       if (warpstring == null)
/*     */       {
/* 179 */         log.warning("[Waypoint] Warp string is null! Please set the warp.string value in config.yml");
/* 180 */         return true;
/*     */       }
/* 182 */       warpstring = warpstring.replaceAll("%w", "" + warpname);
/* 183 */       warpstring = warpstring.replaceAll("%p", "" + target.getName().toString());
/* 184 */       target.sendMessage(String.format("%s%s", new Object[] { ChatColor.BLUE, warpstring }));
/* 185 */       return true;
/*     */     }
/* 187 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Core.Warps
 * JD-Core Version:    0.6.0
 */