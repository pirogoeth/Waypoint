/*     */ package me.pirogoeth.Waypoint.Util;
/*     */ 
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ 
/*     */ public class Test
/*     */ {
/*     */   private Waypoint plugin;
/*  36 */   private Logger log = Logger.getLogger("Minecraft");
/*     */   private Registry registry;
/*     */   public TestCommand commandTest;
/*  39 */   public int i = 0;
/*     */ 
/*  41 */   public Test(Waypoint instance) { this.plugin = instance;
/*  42 */     this.registry = this.plugin.registry;
/*  43 */     this.log.info("{WPT16} Initialising testing classes.");
/*  44 */     this.commandTest = new TestCommand(this.plugin, "waypoint");
/*  45 */     this.log.info("{WPT16} [REGISTRY TESTS]");
/*  46 */     registry_size_Test();
/*  47 */     registry_emptyness_Test();
/*  48 */     registry_put_get_remove_Test();
/*  49 */     registry_process_Test();
/*  50 */     this.log.info("{WPT16} [COMMAND TESTS]");
/*  51 */     command_registration_Test();
/*  52 */     command_deregistration_Test();
/*  53 */     command_modification_Test();
/*  54 */     this.log.info("{WPT16} [MIXED TESTS]");
/*  55 */     command_registration_Test();
/*  56 */     registry_size_Test();
/*  57 */     registry_emptyness_Test();
/*  58 */     command_deregistration_Test();
/*  59 */     this.log.info(String.format("{WPT16} Tests passed: %d/11", new Object[] { Integer.valueOf(this.i) })); } 
/*     */   public void command_registration_Test() {
/*     */     try {
/*  62 */       this.commandTest.register();
/*     */     } catch (CommandException e) {
/*  64 */       return;
/*     */     }
/*  66 */     this.log.info("{WPT16} Command registered.");
/*  67 */     this.i += 1;
/*     */   }
/*     */   public void command_deregistration_Test() {
/*     */     try { this.commandTest.deregister();
/*     */     } catch (CommandException e) {
/*  72 */       return;
/*     */     }
/*  74 */     this.log.info("{WPT16} Command deregistered.");
/*  75 */     this.i += 1;
/*     */   }
/*     */   public void command_modification_Test() {
/*  78 */     TestCommand D = new TestCommand(this.plugin);
/*     */     try {
/*  80 */       D.setCommand("teleport");
/*  81 */       D.register();
/*  82 */       D.setCommand("teleport_d");
/*     */     } catch (CommandException e) {
/*  84 */       this.log.info("{WPT16} setCommand test passed.");
/*     */       try { D.deregister();
/*     */       } catch (CommandException x) {
/*  87 */         return;
/*     */       }
/*  89 */       this.i += 1;
/*  90 */       return;
/*     */     }
/*  92 */     this.log.info("{WPT16} setCommand test failed.");
/*     */     try { D.deregister();
/*     */     } catch (CommandException x) {
/*  95 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registry_size_Test() {
/*  99 */     this.log.info(String.format("{WPT16} Registry size test: [%d]", new Object[] { Integer.valueOf(this.registry.size()) }));
/* 100 */     this.i += 1;
/*     */   }
/*     */   public void registry_emptyness_Test() {
/* 103 */     this.log.info(String.format("{WPT16} Registry emptyness test: [%s]", new Object[] { Boolean.toString(this.registry.isEmpty()) }));
/* 104 */     this.i += 1;
/*     */   }
/*     */   public void registry_put_get_remove_Test() {
/* 107 */     String K = "test";
/* 108 */     Object V = this;
/* 109 */     this.log.info(String.format("{WPT16} Putting K,V into registry.", new Object[0]));
/* 110 */     this.registry.put(K, V);
/* 111 */     this.log.info(String.format("{WPT16} Getting K,V from registry.", new Object[0]));
/* 112 */     if (this.registry.get(K) != this) {
/* 113 */       this.log.info(String.format("{WPT16} [REGISTRY_PUT_GET_REMOVE] FAILED", new Object[0]));
/* 114 */       return;
/*     */     }
/*     */ 
/* 117 */     this.log.info(String.format("{WPT16} Removing K,V from registry.", new Object[0]));
/* 118 */     this.registry.remove(K);
/* 119 */     this.i += 1;
/*     */   }
/*     */ 
/*     */   public void registry_process_Test()
/*     */   {
/* 124 */     Command C = new TestCommand(this.plugin, "test_moar");
/* 125 */     this.log.info(String.format("{WPT16} Registering command and running process()", new Object[0]));
/*     */     try { C.register();
/*     */     } catch (CommandException e) {
/* 128 */       return;
/*     */     }
/* 130 */     if (C.equals(this.registry.process("test_moar"))) {
/* 131 */       this.log.info(String.format("{WPT16} Test successful.", new Object[0]));
/*     */       try { C.deregister();
/*     */       } catch (CommandException e) {
/* 134 */         return;
/*     */       }
/* 136 */       this.i += 1;
/*     */     }
/*     */     else {
/* 139 */       this.log.info("{WPT16} Test [REGISTRY PROCESS] failed.");
/* 140 */       return;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.Test
 * JD-Core Version:    0.6.0
 */