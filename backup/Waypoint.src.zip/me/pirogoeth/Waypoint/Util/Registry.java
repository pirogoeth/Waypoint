/*     */ package me.pirogoeth.Waypoint.Util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ 
/*     */ public class Registry
/*     */ {
/*  21 */   public Map<String, Object> command = new HashMap();
/*  22 */   public Map<String, Object> aliases = new HashMap();
/*  23 */   public final Logger log = Logger.getLogger("Minecraft");
/*     */   public Waypoint plugin;
/*     */ 
/*     */   public Registry(Waypoint instance)
/*     */   {
/*  27 */     this.plugin = instance;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getCommandMap()
/*     */   {
/*  36 */     return this.command;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(String K)
/*     */   {
/*  44 */     return Boolean.valueOf(this.command.containsKey(K)).booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object V)
/*     */   {
/*  52 */     return Boolean.valueOf(this.command.containsValue(V)).booleanValue();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  60 */     return this.command.size();
/*     */   }
/*     */ 
/*     */   public Object get(String K)
/*     */   {
/*  69 */     return this.command.get(K);
/*     */   }
/*     */ 
/*     */   public Object put(String K, Object V)
/*     */   {
/*  80 */     return this.command.put(K, V);
/*     */   }
/*     */ 
/*     */   public Object remove(Object K)
/*     */   {
/*  90 */     return this.command.remove(K);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  99 */     return this.command.isEmpty();
/*     */   }
/*     */ 
/*     */   public Set<String> getCommandSet()
/*     */   {
/* 108 */     return this.command.keySet();
/*     */   }
/*     */ 
/*     */   public boolean registerCommand(String commandLabel, Command commandInst)
/*     */     throws RegistryException
/*     */   {
/* 120 */     if (containsKey(commandLabel)) {
/* 121 */       throw new RegistryException(String.format("Command [%s] is already registered.", new Object[] { commandLabel }));
/*     */     }
/*     */ 
/* 124 */     return put(commandLabel, commandInst) == null;
/*     */   }
/*     */ 
/*     */   public boolean deregisterCommand(String commandLabel)
/*     */     throws RegistryException
/*     */   {
/* 137 */     if (!containsKey(commandLabel)) {
/* 138 */       throw new RegistryException(String.format("Command [%s] is not registered.", new Object[] { commandLabel }));
/*     */     }
/*     */ 
/* 141 */     return (remove(commandLabel) == null) || (remove(commandLabel) != null);
/*     */   }
/*     */ 
/*     */   public void deregisterAll()
/*     */   {
/*     */     try
/*     */     {
/* 154 */       for (Map.Entry pair : this.command.entrySet()) {
/* 155 */         ((Command)pair.getValue()).deregister();
/* 156 */         ((Command)pair.getValue()).deleteAllAliases();
/*     */       }
/*     */     } catch (CommandException e) {
/* 159 */       this.log.warning("[Waypoint{Registry}] Error deregistering all commands.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean registerAlias(String aliasLabel, Command instantiation)
/*     */     throws RegistryException
/*     */   {
/* 174 */     if (this.aliases.containsKey(aliasLabel)) {
/* 175 */       throw new RegistryException(String.format("Command [%s] is already registered.", new Object[] { aliasLabel }));
/*     */     }
/*     */ 
/* 178 */     return this.aliases.put(aliasLabel, instantiation) == null;
/*     */   }
/*     */ 
/*     */   public boolean deregisterAlias(String aliasLabel)
/*     */     throws RegistryException
/*     */   {
/* 192 */     if (!this.aliases.containsKey(aliasLabel)) {
/* 193 */       throw new RegistryException(String.format("Command [%s] is not registered.", new Object[] { aliasLabel }));
/*     */     }
/*     */ 
/* 196 */     return (this.aliases.remove(aliasLabel) == null) || (this.aliases.remove(aliasLabel) != null);
/*     */   }
/*     */ 
/*     */   public Command process(String commandLabel)
/*     */   {
/* 208 */     if (containsKey(commandLabel))
/* 209 */       return (Command)get(commandLabel);
/* 210 */     if (this.aliases.containsKey(commandLabel)) {
/* 211 */       return (Command)this.aliases.get(commandLabel);
/*     */     }
/* 213 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.Registry
 * JD-Core Version:    0.6.0
 */