package me.pirogoeth.Waypoint.Util;

import org.bukkit.util.config.Configuration;
import org.bukkit.util.config.ConfigurationNode;
import org.bukkit.World;
import org.bukkit.World.Environment;
import java.io.File;
import java.util.logging.Logger;
import java.util.Map;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

import me.pirogoeth.Waypoint.Waypoint;

public class Config {
    // main vars
    public static Waypoint plugin;
    public static Logger log = Logger.getLogger("Minecraft");
    public static String maindir = "plugins/Waypoint";
    // quizzical vars
    public static boolean loaded = false;
    // Configuration variables
    public static Configuration main;
    public static Configuration warps;
    public static Configuration users;
    public static Configuration spawn;
    public static Configuration home;
    public static Configuration world;
    public static Configuration links;
    public static Configuration strings;
    // File variables
    public static File mainf;
    public static File spawnf;
    public static File usersf;
    public static File homef;
    public static File warpsf;
    public static File worldf;
    public static File linksf;
    public static File stringf;
    // constructor
    public Config (Waypoint instance)
    {
        plugin = instance;
        new File(maindir).mkdir();
        new File(maindir + "/data").mkdir();
        // do our configuration initialisation here.
        initialise();
    }
    // File() creator
    private static File getFile(String fname)
    {
        File f = new File(maindir + File.separator + (String)fname);
        return f;
    }
    // support method to move old data. 1.6 -> 1.6.1
    public static boolean moveOldData ()
    {
        // old files
        File old_warps = getFile("warps.yml");
        File old_users = getFile("users.yml");
        File old_home = getFile("home.yml");
        File old_links = getFile("links.yml");
        // this is a test. we'll try the java.io.File().renameTo() method first
        try {
            old_warps.renameTo(warpsf);
            old_users.renameTo(usersf);
            old_home.renameTo(homef);
            old_links.renameTo(linksf);
        } catch (Exception e) {
            log.info("[Waypoint] Failed moving old configuration data.");
            return false;
        }
        log.info("[Waypoint] Successfully moved old configuration data.");
        initialise();
        return true;
    }
    // initialise the Configuration setup
    public static boolean initialise ()
    {
        log.info("[Waypoint] Initialising configurations.");
        // load all of the config files
        try {
            mainf = getFile("config.yml");
            warpsf = getFile("data/warps.yml");
            usersf = getFile("data/users.yml");
            spawnf = getFile("spawn.yml");
            homef = getFile("data/home.yml");
            worldf = getFile("world.yml");
            linksf = getFile("data/links.yml");
            // stringf = getFile("strings.yml");
        }
        catch (Exception e) {
            return false;
        }
        // instantiate the Configuration objects
        try {
            main = new Configuration(mainf);
            warps = new Configuration(warpsf);
            users = new Configuration(usersf);
            spawn = new Configuration(spawnf);
            home = new Configuration(homef);
            world = new Configuration(worldf);
            links = new Configuration(linksf);
        }
        catch (Exception e) {
            return false;
        }
        return true;
    }
    public static void load()
    {
        // load all of the configurations
        log.info("[Waypoint] Reading configurations.");
        main.load();
        warps.load();
        users.load();
        spawn.load();
        home.load();
        world.load();
        links.load();
        // world variables
        List<World> world_l;
        Iterator world_l_i;
        World world_o;
        String world_n;
        Environment world_e;
        // check if we need to write the defaults.
        if ((String)main.getString("version") == null)
        {
            log.info("[Waypoint] Writing default config values.");
            // main
            main.setProperty("version", "1.6.1");
            main.setProperty("autoupdate", "true");
            // home settings
            main.setProperty("home.set_home_at_bed", "false");
            // warp permission groups
            List<String> warpgroups = new ArrayList<String>();
            warpgroups.add("Default");
            warpgroups.add("Mod");
            warpgroups.add("Admin");
            main.setProperty("warp.permissions", warpgroups);
            // write the spawn points to config file
            plugin.spawnManager.ConfigWriteSpawnLocations();
            // warp settings
            main.setProperty("warp.traverse_world_only", "false");
            main.setProperty("warp.list_world_only", "false");
            main.setProperty("warp.warpstring_enabled", "true");
            main.setProperty("warp.string", "welcome to %w, %p");
            // limits
            main.setProperty("limits.warp.enabled", true);
            main.setProperty("limits.warp.threshold", 10);
            main.setProperty("limits.waypoint.enabled", true);
            main.setProperty("limits.waypoint.threshold", 10);
            // placeholder
            links.setProperty("links", "");
            // world base and currently loaded world settings
            world_l = plugin.getServer().getWorlds();
            world_l_i = world_l.iterator();
            while (world_l_i.hasNext())
            {
                world_o = (World) world_l_i.next();
                world_n = world_o.getName().toString();
                world_e = world_o.getEnvironment();
                log.info(String.format("[Waypoint] Processing world: { %s : [ENV:%s] }", world_n, (String) Integer.toString(world_e.getId())));
                world.setProperty("world." + world_n, "");
                switch (world_e)
                {
                    case NORMAL:
                        world.setProperty("world." + world_n + ".env", "NORMAL");
                        break;
                    case NETHER:
                        world.setProperty("world." + world_n + ".env", "NETHER");
                        break;
                    case SKYLANDS:
                        world.setProperty("world." + world_n + ".env", "SKYLANDS");
                        break;
                    default:
                        // default shall be NORMAL
                        world.setProperty("world." + world_n + ".env", "NORMAL");
                        break;
                }
            }
            world.save();
            // TODO: actually implement case insensitive warps
            log.info("[Waypoint] Wrote defaults.");
            links.save();
            main.save();
        }
        else if (!((String)main.getString("version")).equals("1.6.1"))
        {
            // write values not entered in the 1.5.9 update, but were added during
            // the 1.6 alpha testing.
            log.info("[Waypoint] Finalising 1.6.1 configuration.");
            // set version
            main.setProperty("version", "1.6.1");
            // add config option added after 1.5-dev
            main.setProperty("warp.warpstring_enabled", "true");
            main.setProperty("warp.string", "welcome to %w, %p");
            // add limits
            // limits
            main.setProperty("limits.warp.enabled", true);
            main.setProperty("limits.warp.threshold", 10);
            main.setProperty("limits.waypoint.enabled", true);
            main.setProperty("limits.waypoint.threshold", 10);
            main.save();
            moveOldData();
        }
        log.info("[Waypoint] Configuration succesfully loaded.");
        loaded = true;
        return;
    }
    public static void save ()
    {
        // use the save() method of all of the Configuration instances.
        main.save();
        users.save();
        warps.save();
        spawn.save();
        home.save();
        links.save();
        log.info("[Waypoint] Saved all configurations.");
    }
    public static Configuration getMain ()
    {
        // returns the Configuration object for the main config file
        return (Configuration) main;
    }
    public static Configuration getWarp ()
    {
        // returns the Configuration object for the warps config file
        return (Configuration) warps;
    }
    public static Configuration getUsers ()
    {
        // returns the Configuration object for the users config file
        return (Configuration) users;
    }
    public static Configuration getSpawn ()
    {
        // returns the Configuration object for the spawn config file
        return (Configuration) spawn;
    }
    public static Configuration getHome ()
    {
        // returns the Configuration object for the home config file
        return (Configuration) home;
    }
    public static Configuration getWorld()
    {
        // returns the Configuration object for the world config file
        return (Configuration) world;
    }
    public static Configuration getLinks()
    {
        // returns the Configuration object for the links config file
        return (Configuration) links;
    }
    /*
     *   Not yet implemented.
     *
     * public static Configuration getStrings()
     * {
     *    // returns the Configuration object for the strings config file
     *    return (Configuration) strings;
     * }
     */
}