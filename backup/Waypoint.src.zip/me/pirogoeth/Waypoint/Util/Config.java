/*     */ package me.pirogoeth.Waypoint.Util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Core.Spawn;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.World.Environment;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ public class Config
/*     */ {
/*     */   public static Waypoint plugin;
/*  19 */   public static Logger log = Logger.getLogger("Minecraft");
/*  20 */   public static String maindir = "plugins/Waypoint";
/*     */ 
/*  22 */   public static boolean loaded = false;
/*     */   public static Configuration main;
/*     */   public static Configuration warps;
/*     */   public static Configuration users;
/*     */   public static Configuration spawn;
/*     */   public static Configuration home;
/*     */   public static Configuration world;
/*     */   public static Configuration links;
/*     */   public static Configuration strings;
/*     */   public static File mainf;
/*     */   public static File spawnf;
/*     */   public static File usersf;
/*     */   public static File homef;
/*     */   public static File warpsf;
/*     */   public static File worldf;
/*     */   public static File linksf;
/*     */   public static File stringf;
/*     */ 
/*     */   public Config(Waypoint instance)
/*     */   {
/*  44 */     plugin = instance;
/*  45 */     new File(maindir).mkdir();
/*  46 */     new File(maindir + "/data").mkdir();
/*     */ 
/*  48 */     initialise();
/*     */   }
/*     */ 
/*     */   private static File getFile(String fname)
/*     */   {
/*  53 */     File f = new File(maindir + File.separator + fname);
/*  54 */     return f;
/*     */   }
/*     */ 
/*     */   public static boolean moveOldData()
/*     */   {
/*  60 */     File old_warps = getFile("warps.yml");
/*  61 */     File old_users = getFile("users.yml");
/*  62 */     File old_home = getFile("home.yml");
/*  63 */     File old_links = getFile("links.yml");
/*     */     try
/*     */     {
/*  66 */       old_warps.renameTo(warpsf);
/*  67 */       old_users.renameTo(usersf);
/*  68 */       old_home.renameTo(homef);
/*  69 */       old_links.renameTo(linksf);
/*     */     } catch (Exception e) {
/*  71 */       log.info("[Waypoint] Failed moving old configuration data.");
/*  72 */       return false;
/*     */     }
/*  74 */     log.info("[Waypoint] Successfully moved old configuration data.");
/*  75 */     initialise();
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean initialise()
/*     */   {
/*  81 */     log.info("[Waypoint] Initialising configurations.");
/*     */     try
/*     */     {
/*  84 */       mainf = getFile("config.yml");
/*  85 */       warpsf = getFile("data/warps.yml");
/*  86 */       usersf = getFile("data/users.yml");
/*  87 */       spawnf = getFile("spawn.yml");
/*  88 */       homef = getFile("data/home.yml");
/*  89 */       worldf = getFile("world.yml");
/*  90 */       linksf = getFile("data/links.yml");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  94 */       return false;
/*     */     }
/*     */     try
/*     */     {
/*  98 */       main = new Configuration(mainf);
/*  99 */       warps = new Configuration(warpsf);
/* 100 */       users = new Configuration(usersf);
/* 101 */       spawn = new Configuration(spawnf);
/* 102 */       home = new Configuration(homef);
/* 103 */       world = new Configuration(worldf);
/* 104 */       links = new Configuration(linksf);
/*     */     }
/*     */     catch (Exception e) {
/* 107 */       return false;
/*     */     }
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   public static void load()
/*     */   {
/* 114 */     log.info("[Waypoint] Reading configurations.");
/* 115 */     main.load();
/* 116 */     warps.load();
/* 117 */     users.load();
/* 118 */     spawn.load();
/* 119 */     home.load();
/* 120 */     world.load();
/* 121 */     links.load();
/*     */ 
/* 129 */     if (main.getString("version") == null)
/*     */     {
/* 131 */       log.info("[Waypoint] Writing default config values.");
/*     */ 
/* 133 */       main.setProperty("version", "1.6.1");
/* 134 */       main.setProperty("autoupdate", "true");
/*     */ 
/* 136 */       main.setProperty("home.set_home_at_bed", "false");
/*     */ 
/* 138 */       List warpgroups = new ArrayList();
/* 139 */       warpgroups.add("Default");
/* 140 */       warpgroups.add("Mod");
/* 141 */       warpgroups.add("Admin");
/* 142 */       main.setProperty("warp.permissions", warpgroups);
/*     */ 
/* 144 */       plugin.spawnManager.ConfigWriteSpawnLocations();
/*     */ 
/* 146 */       main.setProperty("warp.traverse_world_only", "false");
/* 147 */       main.setProperty("warp.list_world_only", "false");
/* 148 */       main.setProperty("warp.warpstring_enabled", "true");
/* 149 */       main.setProperty("warp.string", "welcome to %w, %p");
/*     */ 
/* 151 */       main.setProperty("limits.warp.enabled", Boolean.valueOf(true));
/* 152 */       main.setProperty("limits.warp.threshold", Integer.valueOf(10));
/* 153 */       main.setProperty("limits.waypoint.enabled", Boolean.valueOf(true));
/* 154 */       main.setProperty("limits.waypoint.threshold", Integer.valueOf(10));
/*     */ 
/* 156 */       links.setProperty("links", "");
/*     */ 
/* 158 */       List world_l = plugin.getServer().getWorlds();
/* 159 */       Iterator world_l_i = world_l.iterator();
/* 160 */       while (world_l_i.hasNext())
/*     */       {
/* 162 */         World world_o = (World)world_l_i.next();
/* 163 */         String world_n = world_o.getName().toString();
/* 164 */         World.Environment world_e = world_o.getEnvironment();
/* 165 */         log.info(String.format("[Waypoint] Processing world: { %s : [ENV:%s] }", new Object[] { world_n, Integer.toString(world_e.getId()) }));
/* 166 */         world.setProperty("world." + world_n, "");
/* 167 */         switch (1.$SwitchMap$org$bukkit$World$Environment[world_e.ordinal()])
/*     */         {
/*     */         case 1:
/* 170 */           world.setProperty("world." + world_n + ".env", "NORMAL");
/* 171 */           break;
/*     */         case 2:
/* 173 */           world.setProperty("world." + world_n + ".env", "NETHER");
/* 174 */           break;
/*     */         case 3:
/* 176 */           world.setProperty("world." + world_n + ".env", "SKYLANDS");
/* 177 */           break;
/*     */         default:
/* 180 */           world.setProperty("world." + world_n + ".env", "NORMAL");
/*     */         }
/*     */       }
/*     */ 
/* 184 */       world.save();
/*     */ 
/* 186 */       log.info("[Waypoint] Wrote defaults.");
/* 187 */       links.save();
/* 188 */       main.save();
/*     */     }
/* 190 */     else if (!main.getString("version").equals("1.6.1"))
/*     */     {
/* 194 */       log.info("[Waypoint] Finalising 1.6.1 configuration.");
/*     */ 
/* 196 */       main.setProperty("version", "1.6.1");
/*     */ 
/* 198 */       main.setProperty("warp.warpstring_enabled", "true");
/* 199 */       main.setProperty("warp.string", "welcome to %w, %p");
/*     */ 
/* 202 */       main.setProperty("limits.warp.enabled", Boolean.valueOf(true));
/* 203 */       main.setProperty("limits.warp.threshold", Integer.valueOf(10));
/* 204 */       main.setProperty("limits.waypoint.enabled", Boolean.valueOf(true));
/* 205 */       main.setProperty("limits.waypoint.threshold", Integer.valueOf(10));
/* 206 */       main.save();
/* 207 */       moveOldData();
/*     */     }
/* 209 */     log.info("[Waypoint] Configuration succesfully loaded.");
/* 210 */     loaded = true;
/*     */   }
/*     */ 
/*     */   public static void save()
/*     */   {
/* 216 */     main.save();
/* 217 */     users.save();
/* 218 */     warps.save();
/* 219 */     spawn.save();
/* 220 */     home.save();
/* 221 */     links.save();
/* 222 */     log.info("[Waypoint] Saved all configurations.");
/*     */   }
/*     */ 
/*     */   public static Configuration getMain()
/*     */   {
/* 227 */     return main;
/*     */   }
/*     */ 
/*     */   public static Configuration getWarp()
/*     */   {
/* 232 */     return warps;
/*     */   }
/*     */ 
/*     */   public static Configuration getUsers()
/*     */   {
/* 237 */     return users;
/*     */   }
/*     */ 
/*     */   public static Configuration getSpawn()
/*     */   {
/* 242 */     return spawn;
/*     */   }
/*     */ 
/*     */   public static Configuration getHome()
/*     */   {
/* 247 */     return home;
/*     */   }
/*     */ 
/*     */   public static Configuration getWorld()
/*     */   {
/* 252 */     return world;
/*     */   }
/*     */ 
/*     */   public static Configuration getLinks()
/*     */   {
/* 257 */     return links;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.Config
 * JD-Core Version:    0.6.0
 */