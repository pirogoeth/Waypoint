/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class RegistryException extends Exception
/*    */ {
/*    */   protected static String error;
/*  7 */   public Logger log = Logger.getLogger("Minecraft");
/*    */ 
/*    */   public RegistryException() {
/* 10 */     error = "An unknown error occurred.";
/* 11 */     this.log.warning(error);
/*    */   }
/*    */   public RegistryException(String err) {
/* 14 */     super(err);
/* 15 */     error = err;
/* 16 */     this.log.warning(error);
/*    */   }
/*    */   public static String getError() {
/* 19 */     return error;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.RegistryException
 * JD-Core Version:    0.6.0
 */