/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import com.nijiko.permissions.PermissionHandler;
/*    */ import com.nijikokun.bukkit.Permissions.Permissions;
/*    */ import java.util.logging.Logger;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.PluginDescriptionFile;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class Permission
/*    */ {
/*    */   private Waypoint plugin;
/* 17 */   private static HandlerType handler = HandlerType.OP;
/*    */   private static PermissionHandler permissionPlugin;
/*    */ 
/*    */   public Permission(Waypoint instance)
/*    */   {
/* 22 */     this.plugin = instance;
/* 23 */     Logger log = Logger.getLogger("Minecraft");
/* 24 */     Plugin permissions = this.plugin.getServer().getPluginManager().getPlugin("Permissions");
/* 25 */     Plugin superperms_s = this.plugin.getServer().getPluginManager().getPlugin("PermissionsBukkit");
/* 26 */     if (permissions != null)
/*    */     {
/* 28 */       permissionPlugin = ((Permissions)permissions).getHandler();
/* 29 */       handler = HandlerType.PERMISSIONS;
/* 30 */       log.info("[Waypoint] Permissions plugin detected. Using " + permissions.getDescription().getFullName());
/*    */     }
/* 32 */     else if ((permissions == null) && (superperms_s != null))
/*    */     {
/* 34 */       handler = HandlerType.SUPERPERMS;
/* 35 */       log.info("[Waypoint] Using Bukkit SuperPerms, PermissionsBukkit detected.");
/*    */     }
/*    */     else
/*    */     {
/* 39 */       log.info("[Waypoint] No Permissions plugin detected. Using OP");
/*    */     }
/*    */   }
/*    */ 
/*    */   public static boolean has(Player p, String node)
/*    */   {
/* 49 */     switch (1.$SwitchMap$me$pirogoeth$Waypoint$Util$Permission$HandlerType[handler.ordinal()]) {
/*    */     case 1:
/* 51 */       return permissionPlugin.has(p, node);
/*    */     case 2:
/* 53 */       return p.isOp();
/*    */     case 3:
/* 55 */       return p.hasPermission(node);
/*    */     }
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   private static boolean hasPermission(Player p, String node, boolean def) {
/* 61 */     switch (1.$SwitchMap$me$pirogoeth$Waypoint$Util$Permission$HandlerType[handler.ordinal()]) {
/*    */     case 1:
/* 63 */       return permissionPlugin.has(p, node);
/*    */     case 2:
/* 65 */       return def ? true : p.isOp();
/*    */     case 3:
/* 67 */       return p.hasPermission(node);
/*    */     }
/* 69 */     return def;
/*    */   }
/*    */ 
/*    */   private static enum HandlerType
/*    */   {
/* 43 */     PERMISSIONS, 
/* 44 */     OP, 
/* 45 */     SUPERPERMS;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.Permission
 * JD-Core Version:    0.6.0
 */