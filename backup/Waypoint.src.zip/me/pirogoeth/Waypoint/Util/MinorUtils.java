/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ import org.bukkit.util.config.ConfigurationNode;
/*    */ 
/*    */ public class MinorUtils
/*    */ {
/*    */   public static String BaseNodeChomp(Player p, String node)
/*    */   {
/* 12 */     String a = "users." + p.getName().toString() + "." + node;
/* 13 */     return a;
/*    */   }
/*    */ 
/*    */   public static String UserNodeChomp(Player p, String targetname, String sub) {
/* 17 */     String a = "users." + p.getName().toString() + "." + targetname + "." + sub;
/* 18 */     return a;
/*    */   }
/*    */ 
/*    */   public static String HomeNodeChomp(Player p, World world, String sub) {
/* 22 */     String a = "home." + p.getName().toString() + "." + world.getName().toString() + "." + sub;
/* 23 */     return a;
/*    */   }
/*    */ 
/*    */   public static String InviteNodeChomp(Player p, String node) {
/* 27 */     String a = "invites." + p.getName().toString() + "." + node;
/* 28 */     return a;
/*    */   }
/*    */ 
/*    */   public static void TransferNode(Configuration users, String path, ConfigurationNode node) {
/* 32 */     Map a = node.getAll();
/* 33 */     for (Map.Entry entry : a.entrySet())
/*    */     {
/* 35 */       users.setProperty(path + "." + (String)entry.getKey(), entry.getValue());
/*    */     }
/*    */   }
/*    */ 
/*    */   public static boolean CheckPointExists(Configuration users, Player p, String point)
/*    */   {
/* 43 */     String a = "users." + p.getName().toString() + "." + point;
/* 44 */     if (users.getProperty(a + ".coord") == null) {
/* 45 */       return false;
/*    */     }
/* 47 */     return users.getProperty(a + ".coord") != null;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.MinorUtils
 * JD-Core Version:    0.6.0
 */