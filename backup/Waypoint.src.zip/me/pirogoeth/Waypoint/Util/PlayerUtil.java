/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class PlayerUtil
/*    */ {
/*    */   public static Player getPlayerFromSender(CommandSender sender)
/*    */   {
/* 11 */     Player p = (Player)sender;
/* 12 */     return p;
/*    */   }
/*    */ 
/*    */   public static String getPlayerName(CommandSender sender) {
/* 16 */     Player p = (Player)sender;
/* 17 */     String n = p.getDisplayName();
/* 18 */     return n;
/*    */   }
/*    */ 
/*    */   public static Location getPlayerLocation(CommandSender sender) {
/* 22 */     Player p = (Player)sender;
/* 23 */     Location l = p.getLocation();
/* 24 */     return l;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.PlayerUtil
 * JD-Core Version:    0.6.0
 */