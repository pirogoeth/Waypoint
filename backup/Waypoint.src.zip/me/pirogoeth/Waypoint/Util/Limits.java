/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ public class Limits
/*    */ {
/*    */   private String base_path;
/*    */   private int threshold;
/*    */   private Waypoint plugin;
/*    */   private Configuration source;
/*    */ 
/*    */   Limits(Waypoint instance, String path, Configuration input, int limit)
/*    */   {
/* 20 */     this.plugin = instance;
/* 21 */     this.base_path = path;
/* 22 */     this.threshold = limit;
/* 23 */     this.source = input;
/*    */   }
/*    */ 
/*    */   Limits(Waypoint instance, String path, Configuration input) {
/* 27 */     this.plugin = instance;
/* 28 */     this.base_path = path;
/* 29 */     this.threshold = 10;
/* 30 */     this.source = input;
/*    */   }
/*    */ 
/*    */   Limits(Waypoint instance) {
/* 34 */     this.plugin = instance;
/* 35 */     this.base_path = ".";
/* 36 */     this.threshold = 0;
/*    */   }
/*    */   public boolean isEnabled() {
/* 39 */     if (this.base_path.equals(".")) {
/* 40 */       return false;
/*    */     }
/* 42 */     return !this.base_path.equals(".");
/*    */   }
/*    */ 
/*    */   public boolean playerReachedLimit(Player player)
/*    */   {
/* 47 */     Map node_map = this.source.getNodes(String.format("%s.%s", new Object[] { this.base_path, player.getName().toString() }));
/* 48 */     if (node_map.size() < this.threshold)
/* 49 */       return false;
/* 50 */     if (node_map.size() == this.threshold) {
/* 51 */       return true;
/*    */     }
/* 53 */     return node_map.size() > this.threshold;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.Limits
 * JD-Core Version:    0.6.0
 */