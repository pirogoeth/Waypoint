/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ class TestCommand extends Command
/*    */ {
/*    */   public TestCommand(Waypoint instance)
/*    */   {
/* 13 */     super(instance);
/*    */   }
/*    */   public TestCommand(Waypoint instance, String command) {
/* 16 */     super(instance, command);
/*    */   }
/*    */ 
/*    */   public boolean run(Player player, String[] args)
/*    */     throws CommandException
/*    */   {
/* 29 */     this.log.info("{WPT16} TestCommand has been run.");
/* 30 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.TestCommand
 * JD-Core Version:    0.6.0
 */