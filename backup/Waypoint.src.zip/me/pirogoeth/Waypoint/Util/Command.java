/*     */ package me.pirogoeth.Waypoint.Util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class Command
/*     */ {
/*  25 */   public Logger log = Logger.getLogger("Minecraft");
/*     */   public Config configuration;
/*     */   public Permission permissions;
/*     */   public Registry registry;
/*     */   public Waypoint plugin;
/*  32 */   public boolean registered = false;
/*  33 */   public String command = "";
/*  34 */   public ArrayList<String> aliases = new ArrayList();
/*     */ 
/*     */   public Command(Waypoint instance)
/*     */   {
/*  38 */     this.plugin = instance;
/*  39 */     this.permissions = this.plugin.permissions;
/*  40 */     this.configuration = this.plugin.config;
/*  41 */     this.registry = this.plugin.registry;
/*  42 */     this.command = null;
/*     */   }
/*     */ 
/*     */   public Command(Waypoint instance, String command_root)
/*     */   {
/*  47 */     this.plugin = instance;
/*  48 */     this.permissions = this.plugin.permissions;
/*  49 */     this.configuration = this.plugin.config;
/*  50 */     this.registry = this.plugin.registry;
/*  51 */     this.command = command_root;
/*     */   }
/*     */ 
/*     */   public boolean addAlias(String alias)
/*     */   {
/*     */     try
/*     */     {
/*  60 */       if (this.registry.registerAlias(alias, this) == true)
/*  61 */         return this.aliases.add(alias);
/*     */     } catch (RegistryException e) {
/*  63 */       this.log.info("[Waypoint{Registry}] Could not register alias '" + alias + "'.");
/*  64 */       return false;
/*     */     }
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean deleteAlias(String alias)
/*     */     throws CommandException
/*     */   {
/*     */     try
/*     */     {
/*  75 */       if (this.registry.deregisterAlias(alias) == true) {
/*  76 */         return this.aliases.remove(alias);
/*     */       }
/*  78 */       throw new CommandException(String.format("Alias [%s] does not exist.", new Object[] { alias }));
/*     */     } catch (RegistryException e) {
/*  80 */       this.log.info("[Waypoint{Registry}] Could not deregister alias '" + alias + "'.");
/*  81 */     }return false;
/*     */   }
/*     */ 
/*     */   public boolean deleteAllAliases()
/*     */     throws CommandException
/*     */   {
/*  90 */     Iterator alia_i = this.aliases.iterator();
/*     */ 
/*  92 */     if (alia_i.hasNext()) {
/*  93 */       String a = (String)alia_i.next();
/*     */       try {
/*  95 */         this.registry.deregisterAlias(a);
/*     */       } catch (RegistryException e) {
/*  97 */         this.log.info("[Waypoint{Registry}] Could not deregister alias '" + a + "'.");
/*  98 */         return false;
/*     */       }
/* 100 */       return true;
/*     */     }
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isRegistered()
/*     */   {
/* 109 */     return Boolean.valueOf(this.registered).booleanValue();
/*     */   }
/*     */ 
/*     */   public String getCommand()
/*     */   {
/* 116 */     return this.command;
/*     */   }
/*     */ 
/*     */   public void setCommand(String cmd)
/*     */     throws CommandException
/*     */   {
/* 125 */     if (this.registered == true) {
/* 126 */       throw new CommandException("Command cannot be set with the command already registered.");
/*     */     }
/* 128 */     this.command = cmd;
/*     */   }
/*     */ 
/*     */   public boolean register()
/*     */     throws CommandException
/*     */   {
/* 137 */     if (this.registered == true)
/* 138 */       throw new CommandException("Command instance cannot be re-registered.");
/*     */     try
/*     */     {
/* 141 */       this.registry.registerCommand(this.command, this);
/*     */     } catch (RegistryException e) {
/* 143 */       this.log.info("[Waypoint{Registry}] Could not register command '" + this.command + "'.");
/* 144 */       this.registered = false;
/* 145 */       return false;
/*     */     }
/* 147 */     this.registered = true;
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean deregister()
/*     */     throws CommandException
/*     */   {
/* 156 */     if (!this.registered)
/* 157 */       throw new CommandException("Command instance is not registered.");
/*     */     try {
/* 159 */       this.registry.deregisterCommand(this.command);
/*     */     } catch (RegistryException e) {
/* 161 */       this.registered = true;
/* 162 */       return false;
/*     */     }
/* 164 */     this.registered = false;
/* 165 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean run(Player player, String[] args)
/*     */     throws CommandException
/*     */   {
/* 176 */     if (!this.registered) {
/* 177 */       throw new CommandException("Command is not registered.");
/*     */     }
/* 179 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.Command
 * JD-Core Version:    0.6.0
 */