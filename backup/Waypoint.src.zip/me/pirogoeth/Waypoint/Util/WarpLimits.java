/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ import org.bukkit.util.config.ConfigurationNode;
/*    */ 
/*    */ public class WarpLimits extends Limits
/*    */ {
/*    */   private String base_path;
/*    */   private int threshold;
/*    */   private Waypoint plugin;
/*    */   private Configuration source;
/*    */ 
/*    */   WarpLimits(Waypoint instance, String path, Configuration input, int limit)
/*    */   {
/* 21 */     super(instance, path, input, limit);
/*    */   }
/*    */ 
/*    */   WarpLimits(Waypoint instance, String path, Configuration input) {
/* 25 */     super(instance, path, input);
/*    */   }
/*    */ 
/*    */   WarpLimits(Waypoint instance) {
/* 29 */     super(instance);
/*    */   }
/*    */ 
/*    */   public boolean playerReachedLimit(Player player) {
/* 33 */     Map node_map = this.source.getNodes(this.base_path);
/* 34 */     int size = 0;
/* 35 */     for (Map.Entry entry : node_map.entrySet()) {
/* 36 */       if (((ConfigurationNode)entry.getValue()).getString("owner").equals(player.getName().toString())) {
/* 37 */         size++;
/*    */       }
/*    */     }
/*    */ 
/* 41 */     if (size < this.threshold)
/* 42 */       return false;
/* 43 */     if (size == this.threshold) {
/* 44 */       return true;
/*    */     }
/* 46 */     return size > this.threshold;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.WarpLimits
 * JD-Core Version:    0.6.0
 */