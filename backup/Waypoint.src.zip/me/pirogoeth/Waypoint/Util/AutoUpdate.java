/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import java.nio.channels.Channels;
/*    */ import java.nio.channels.FileChannel;
/*    */ import java.nio.channels.ReadableByteChannel;
/*    */ import java.util.logging.Logger;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.plugin.PluginDescriptionFile;
/*    */ import org.bukkit.util.FileUtil;
/*    */ import org.bukkit.util.config.Configuration;
/*    */ 
/*    */ public class AutoUpdate
/*    */ {
/*    */   public File jar;
/* 20 */   public Logger log = Logger.getLogger("Minecraft");
/*    */   public Waypoint plugin;
/*    */   public Configuration main;
/*    */ 
/*    */   public AutoUpdate(Waypoint instance)
/*    */   {
/* 25 */     this.plugin = instance;
/* 26 */     this.main = Config.getMain();
/*    */   }
/*    */ 
/*    */   public void finalise() {
/*    */     try {
/* 31 */       File directory = new File(Bukkit.getServer().getUpdateFolder());
/* 32 */       if (directory.exists()) {
/* 33 */         File p = new File(directory.getPath(), "Waypoint.jar");
/* 34 */         if (p.exists()) {
/* 35 */           FileUtil.copy(p, this.plugin.fileGet());
/* 36 */           p.delete();
/* 37 */           this.log.info("[Waypoint] Update finalised.");
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/*    */     }
/*    */   }
/*    */ 
/*    */   protected int getVersion() {
/*    */     try {
/* 45 */       String[] split = this.plugin.getDescription().getVersion().split("\\.");
/* 46 */       return Integer.parseInt(split[0]) * 100 + Integer.parseInt(split[1]) * 10 + Integer.parseInt(split[2]);
/*    */     } catch (Exception e) {
/*    */     }
/* 49 */     return -1;
/*    */   }
/*    */   protected boolean checkUpdate() {
/* 52 */     if (!this.main.getString("autoupdate").equalsIgnoreCase("true")) {
/* 53 */       this.log.info("[Waypoint] Auto-update is disabled.");
/* 54 */       return false;
/*    */     }
/*    */     try {
/* 57 */       URL versionfile = new URL("http://maio.me/~pirogoeth/Waypoint.version.txt");
/* 58 */       this.log.info("[Waypoint] Checking for updates..");
/* 59 */       BufferedReader in = new BufferedReader(new InputStreamReader(versionfile.openStream()));
/*    */       String str;
/* 61 */       while ((str = in.readLine()) != null) {
/* 62 */         String[] split = str.split("\\.");
/* 63 */         int version = Integer.parseInt(split[0]) * 100 + Integer.parseInt(split[1]) * 10 + Integer.parseInt(split[2]);
/* 64 */         if (version > getVersion()) {
/* 65 */           in.close();
/* 66 */           this.log.info(String.format("[Waypoint] Update found. %s->%s :: Now Updating.", new Object[] { Integer.valueOf(getVersion()), Integer.valueOf(version) }));
/* 67 */           return true;
/*    */         }
/*    */       }
/* 70 */       in.close();
/*    */     }
/*    */     catch (Exception e) {
/* 73 */       this.log.info("[Waypoint] Error while checking for updates. (It could be a dev build.)");
/* 74 */       return false;
/*    */     }
/* 76 */     this.log.info("[Waypoint] No updates available.");
/* 77 */     return false;
/*    */   }
/*    */   public void doUpdate() {
/* 80 */     if (!checkUpdate())
/* 81 */       return;
/*    */     try
/*    */     {
/* 84 */       URL source = new URL("http://maio.me/~pirogoeth/Waypoint.jar");
/* 85 */       File directory = new File(Bukkit.getServer().getUpdateFolder());
/* 86 */       if (!directory.exists()) {
/* 87 */         directory.mkdir();
/*    */       }
/* 89 */       File plugin = new File(directory.getPath(), "Waypoint.jar");
/* 90 */       if (!plugin.exists()) {
/* 91 */         HttpURLConnection con = (HttpURLConnection)(HttpURLConnection)source.openConnection();
/* 92 */         ReadableByteChannel rbc = Channels.newChannel(con.getInputStream());
/* 93 */         FileOutputStream fos = new FileOutputStream(plugin);
/* 94 */         fos.getChannel().transferFrom(rbc, 0L, 16777216L);
/* 95 */         fos.close();
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.AutoUpdate
 * JD-Core Version:    0.6.0
 */