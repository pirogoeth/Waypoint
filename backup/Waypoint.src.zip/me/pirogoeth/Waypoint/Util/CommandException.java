/*    */ package me.pirogoeth.Waypoint.Util;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public class CommandException extends Exception
/*    */ {
/*    */   protected static String trace;
/*  7 */   public Logger log = Logger.getLogger("Minecraft");
/*    */ 
/*    */   public CommandException() {
/* 10 */     trace = "Unknown sub-exception handled.";
/* 11 */     this.log.warning("[Waypoint{Command}] " + trace);
/*    */   }
/*    */ 
/*    */   public CommandException(String error) {
/* 15 */     super(error);
/* 16 */     trace = error;
/* 17 */     this.log.warning("[Waypoint{Command}] " + trace);
/*    */   }
/*    */ 
/*    */   public static String getError() {
/* 21 */     return trace;
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Util.CommandException
 * JD-Core Version:    0.6.0
 */