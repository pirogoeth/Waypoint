/*    */ package me.pirogoeth.Waypoint.Events;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ import me.pirogoeth.Waypoint.Core.Links;
/*    */ import me.pirogoeth.Waypoint.Core.Warps;
/*    */ import me.pirogoeth.Waypoint.Util.Config;
/*    */ import me.pirogoeth.Waypoint.Util.Permission;
/*    */ import me.pirogoeth.Waypoint.Waypoint;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.block.Sign;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ import org.bukkit.event.block.BlockListener;
/*    */ import org.bukkit.event.block.SignChangeEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BlockEventListener extends BlockListener
/*    */ {
/*    */   public static Waypoint plugin;
/*    */   public static Config config;
/*    */   public static Warps warpManager;
/*    */   public static Links linkManager;
/*    */   public Permission permission;
/* 31 */   Logger log = Logger.getLogger("Minecraft");
/*    */ 
/*    */   public BlockEventListener(Waypoint instance) {
/* 34 */     plugin = instance;
/* 35 */     this.permission = plugin.permissions;
/* 36 */     config = plugin.config;
/* 37 */     warpManager = plugin.warpManager;
/* 38 */     linkManager = plugin.linkManager;
/*    */   }
/*    */ 
/*    */   public void onSignChange(SignChangeEvent event)
/*    */   {
/* 47 */     Player player = event.getPlayer();
/* 48 */     Sign sign = (Sign)event.getBlock().getState();
/* 49 */     Location sign_l = sign.getBlock().getLocation();
/* 50 */     if (!event.getLine(0).equalsIgnoreCase("[Waypoint]")) return;
/* 51 */     if (!Permission.has(player, "waypoint.sign.link.create"))
/*    */     {
/* 53 */       player.sendMessage(ChatColor.RED + "[Waypoint] You do not have permission to create a link sign.");
/* 54 */       int id = new Integer("63").intValue();
/* 55 */       ItemStack sign_st = new ItemStack(id);
/* 56 */       sign.getBlock().setTypeId(0);
/* 57 */       sign_l.getWorld().dropItemNaturally(sign_l, sign_st);
/* 58 */       return;
/*    */     }
/* 60 */     if (!event.getLine(1).split("\\:")[0].equalsIgnoreCase("link")) return;
/* 61 */     if (event.getLine(1).split("\\:")[0].equalsIgnoreCase("link"))
/*    */     {
/* 63 */       linkManager.CreateLink(player, event.getBlock(), (String[])event.getLines());
/*    */     }
/*    */   }
/*    */ 
/*    */   public void onBlockBreak(BlockBreakEvent event)
/*    */   {
/* 73 */     if (((event.getBlock().getTypeId() == 63) || (event.getBlock().getTypeId() == 68)) && (((Sign)event.getBlock().getState()).getLine(0).equalsIgnoreCase("[Waypoint]")))
/*    */     {
/* 75 */       Sign sign = (Sign)event.getBlock().getState();
/* 76 */       if ((sign.getLine(1).split("\\:")[0].equalsIgnoreCase("link")) && (Permission.has(event.getPlayer(), "waypoint.sign.link.delete")))
/*    */       {
/* 78 */         linkManager.DeleteSign((Sign)event.getBlock().getState(), (String[])((Sign)event.getBlock().getState()).getLines());
/* 79 */         return;
/*    */       }
/* 81 */       if ((sign.getLine(1).split("\\:")[0].equalsIgnoreCase("link")) && (Permission.has(event.getPlayer(), "waypoint.sign.link.delete")))
/*    */       {
/* 83 */         event.setCancelled(true);
/* 84 */         event.getPlayer().sendMessage(ChatColor.RED + "[Waypoint] You are not allowed to break this sign!");
/* 85 */         return;
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Events.BlockEventListener
 * JD-Core Version:    0.6.0
 */