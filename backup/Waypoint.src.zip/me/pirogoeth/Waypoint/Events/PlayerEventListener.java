/*     */ package me.pirogoeth.Waypoint.Events;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import me.pirogoeth.Waypoint.Core.Links;
/*     */ import me.pirogoeth.Waypoint.Core.Warps;
/*     */ import me.pirogoeth.Waypoint.Util.Config;
/*     */ import me.pirogoeth.Waypoint.Util.Permission;
/*     */ import me.pirogoeth.Waypoint.Waypoint;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Sign;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerBedEnterEvent;
/*     */ import org.bukkit.event.player.PlayerChangedWorldEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerListener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.util.config.Configuration;
/*     */ 
/*     */ public class PlayerEventListener extends PlayerListener
/*     */ {
/*     */   public static Waypoint plugin;
/*     */   public static Config config;
/*     */   public static Warps warpManager;
/*     */   public static Links linkManager;
/*     */   public Permission permissions;
/*  37 */   Logger log = Logger.getLogger("Minecraft");
/*     */ 
/*     */   public PlayerEventListener(Waypoint instance) {
/*  40 */     plugin = instance;
/*  41 */     this.permissions = plugin.permissions;
/*  42 */     config = plugin.config;
/*  43 */     warpManager = plugin.warpManager;
/*  44 */     linkManager = plugin.linkManager;
/*     */   }
/*     */ 
/*     */   public static String UserNodeChomp(Player p, String arg, String sub) {
/*  48 */     String a = "users." + p.getName().toString() + "." + arg + "." + sub;
/*  49 */     return a;
/*     */   }
/*     */ 
/*     */   public static String HomeNodeChomp(Player p, World w, String sub) {
/*  53 */     String a = "home." + p.getName().toString() + "." + w.getName().toString() + "." + sub;
/*  54 */     return a;
/*     */   }
/*     */ 
/*     */   public void onPlayerBedEnter(PlayerBedEnterEvent event) {
/*  58 */     Player player = event.getPlayer();
/*  59 */     if (!Config.getMain().getBoolean("home.set_home_at_bed", false)) return;
/*  60 */     if (!Permission.has(player, "waypoint.home.set_on_bed_leave")) return;
/*  61 */     double x = player.getLocation().getX();
/*  62 */     double y = player.getLocation().getY();
/*  63 */     double z = player.getLocation().getZ();
/*  64 */     World w = player.getLocation().getWorld();
/*  65 */     Config.getUsers().setProperty(HomeNodeChomp(player, w, "coord.X"), Double.valueOf(x));
/*  66 */     Config.getUsers().setProperty(HomeNodeChomp(player, w, "coord.Y"), Double.valueOf(y));
/*  67 */     Config.getUsers().setProperty(HomeNodeChomp(player, w, "coord.Z"), Double.valueOf(z));
/*  68 */     Config.getUsers().save();
/*  69 */     if (player != null)
/*     */     {
/*  71 */       player.sendMessage(ChatColor.AQUA + "[Waypoint] " + player.getName().toString() + ", your home for world " + player.getWorld().getName().toString() + " has been set to the bed you just entered.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onPlayerJoin(PlayerJoinEvent event) {
/*  76 */     Player player = event.getPlayer();
/*  77 */     String worldname = player.getLocation().getWorld().getName().toString();
/*  78 */     if (Config.getWorld().getProperty(String.format("worlds.%s.env", new Object[] { worldname })) == null) {
/*  79 */       return;
/*     */     }
/*  81 */     GameMode mode = GameMode.getByValue(Config.getWorld().getInt(String.format("worlds.%s.mode", new Object[] { worldname }), 0));
/*  82 */     player.setGameMode(mode);
/*     */   }
/*     */ 
/*     */   public void onPlayerChangedWorld(PlayerChangedWorldEvent event)
/*     */   {
/*  88 */     Player player = event.getPlayer();
/*     */ 
/*  92 */     if (!Permission.has(player, String.format("waypoint.world.access.%s", new Object[] { player.getLocation().getWorld().getName().toString() })))
/*     */     {
/*  94 */       World player_prev_w = event.getFrom();
/*  95 */       Location prev_sl = player_prev_w.getSpawnLocation();
/*  96 */       player.teleport(prev_sl);
/*  97 */       player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to access this world.");
/*  98 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onPlayerInteract(PlayerInteractEvent event)
/*     */   {
/* 104 */     Player player = event.getPlayer();
/*     */ 
/* 110 */     Block clicked_b = event.getClickedBlock();
/* 111 */     if (clicked_b == null) return;
/* 112 */     if (((clicked_b.getTypeId() == 63) || (clicked_b.getTypeId() == 68)) && (event.getAction() == Action.RIGHT_CLICK_BLOCK))
/*     */     {
/* 114 */       Sign clicked_s = (Sign)clicked_b.getState();
/* 115 */       if (!clicked_s.getLine(0).equalsIgnoreCase("[Waypoint]"))
/*     */       {
/* 117 */         return;
/*     */       }
/* 119 */       String signtype = clicked_s.getLine(1);
/* 120 */       String target = null;
/* 121 */       String target_o = null;
/* 122 */       String wrap = null;
/* 123 */       if (signtype.split("\\:")[0].equalsIgnoreCase("link"))
/*     */       {
/* 125 */         if (!Permission.has(player, "waypoint.sign.link.use"))
/*     */         {
/* 127 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to use this sign.");
/* 128 */           return;
/*     */         }
/*     */         try {
/* 131 */           linkManager.PlayerBetweenNetwork(player, clicked_s, (String[])((Sign)clicked_b.getState()).getLines());
/*     */         }
/*     */         catch (NullPointerException e)
/*     */         {
/* 135 */           return;
/*     */         }
/* 137 */         return;
/*     */       }
/*     */       try {
/* 140 */         target = clicked_s.getLine(2);
/*     */       }
/*     */       catch (IndexOutOfBoundsException e)
/*     */       {
/* 144 */         target = null;
/*     */       }
/* 146 */       target_o = target;
/* 147 */       target = target.replaceAll("\\p{Cntrl}", "");
/* 148 */       if ((signtype.equalsIgnoreCase("warp")) && (target_o != null))
/*     */       {
/* 150 */         if (!Permission.has(player, "waypoint.sign.warp"))
/*     */         {
/* 152 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to use this sign.");
/* 153 */           return;
/*     */         }
/* 155 */         boolean result = warpManager.PlayerToWarp(player, target);
/* 156 */         if (!result)
/*     */         {
/* 158 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] The warp name listed on this sign is invalid.");
/* 159 */           int id = new Integer("63").intValue();
/* 160 */           ItemStack sign_dr = new ItemStack(id);
/* 161 */           clicked_b.setTypeId(0);
/* 162 */           clicked_b.getLocation().getWorld().dropItemNaturally(clicked_b.getLocation(), sign_dr);
/* 163 */           return;
/*     */         }
/* 165 */         return;
/*     */       }
/* 167 */       if ((signtype.equalsIgnoreCase("world")) && (target_o != null))
/*     */       {
/* 169 */         if (!Permission.has(player, "waypoint.sign.world"))
/*     */         {
/* 171 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] You do not have permission to use this sign.");
/* 172 */           return;
/*     */         }
/* 174 */         World world_t = plugin.getServer().getWorld(target);
/* 175 */         Location world_l = null;
/* 176 */         if (world_t == null)
/*     */         {
/* 179 */           List wlist = plugin.getServer().getWorlds();
/* 180 */           Iterator witer = wlist.iterator();
/*     */ 
/* 182 */           while (witer.hasNext())
/*     */           {
/* 184 */             World w = (World)witer.next();
/* 185 */             if (!w.getName().toString().contains(target))
/*     */               continue;
/* 187 */             target = w.getName().toString();
/* 188 */             world_t = plugin.getServer().getWorld(target);
/* 189 */             player.teleport(world_t.getSpawnLocation());
/* 190 */             player.sendMessage(ChatColor.GREEN + "[Waypoint] You have been teleported to the spawn of " + target);
/* 191 */             return;
/*     */           }
/*     */ 
/* 194 */           player.sendMessage(ChatColor.BLUE + "[Waypoint] The world name listed on this sign is invalid.");
/* 195 */           int id = new Integer("63").intValue();
/* 196 */           ItemStack sign_dr = new ItemStack(id);
/* 197 */           clicked_b.setTypeId(0);
/* 198 */           clicked_b.getLocation().getWorld().dropItemNaturally(clicked_b.getLocation(), sign_dr);
/* 199 */           return;
/*     */         }
/* 201 */         if (world_t != null)
/*     */         {
/* 203 */           world_l = world_t.getSpawnLocation();
/*     */         }
/* 205 */         player.teleport(world_l);
/* 206 */         player.sendMessage(ChatColor.GREEN + "[Waypoint] You have been teleported to the spawn of " + target);
/* 207 */         return;
/*     */       }
/* 209 */       return;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\CJ\Desktop\Waypoint.jar
 * Qualified Name:     me.pirogoeth.Waypoint.Events.PlayerEventListener
 * JD-Core Version:    0.6.0
 */